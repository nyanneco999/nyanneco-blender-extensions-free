from __future__ import annotations

from datetime import datetime
from time import monotonic

import bpy
from bpy.app.handlers import persistent

from .constants import OBJECT_UUID_PROP, SUPPORTED_OBJECT_TYPES
from .features import FEATURE_TIMER_AUTOCOMMIT, is_feature_enabled
from .models import CommitRecord
from .storage import (
    clear_readonly_history_cache,
    enforce_snapshot_collection_lock,
    enforce_snapshot_collection_visibility_lock,
    get_linked_object_issue,
    load_history_readonly,
    repair_duplicate_object_uuids,
    repository_integrity_warnings,
    store_commit,
)
from .translations import iface_format, iface_text

_is_maintaining_snapshot_state = False
SNAPSHOT_COLLECTION_LOCK_INTERVAL = 0.1
REPOSITORY_INTEGRITY_CHECK_INTERVAL = 2.0
TIMER_AUTOCOMMIT_CHECK_INTERVAL = 60.0
DUPLICATE_UUID_REPAIR_DELAY = 0.1
_is_timer_autocommitting = False
_is_duplicate_uuid_repair_scheduled = False
_last_repository_integrity_check_at = 0.0
_last_repository_integrity_warning_signature: tuple[str, ...] | None = None
_last_timer_autocommit_at_by_scene: dict[str, float] = {}
_dirty_commit_drafts: set[tuple[str, str]] = set()
_suppress_draft_dirty_until: dict[tuple[str, str], float] = {}


def maintain_snapshot_state(create: bool = False, repair_duplicates: bool = True) -> None:
    global _is_maintaining_snapshot_state
    if _is_maintaining_snapshot_state:
        return

    _is_maintaining_snapshot_state = True
    try:
        enforce_snapshot_collection_lock(create=create)
        if repair_duplicates:
            repair_duplicate_object_uuids()
    finally:
        _is_maintaining_snapshot_state = False


def timer_autocommit_interval_seconds(scene: bpy.types.Scene) -> float:
    minutes = getattr(scene, "nyanneco_object_snapshot_timer_autocommit_minutes", 10)
    return max(1, int(minutes)) * 60.0


def timer_autocommit_enabled(scene: bpy.types.Scene | None) -> bool:
    if scene is None:
        return False
    if not is_feature_enabled(FEATURE_TIMER_AUTOCOMMIT):
        return False
    return bool(getattr(scene, "nyanneco_object_snapshot_timer_autocommit_enabled", False))


def active_object_latest_commit_age_seconds(context: bpy.types.Context) -> float | None:
    obj = context.object
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        return None

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return None

    object_history = load_history_readonly().objects.get(str(object_uuid))
    if object_history is None or not object_history.commits:
        return None

    try:
        latest_commit_time = datetime.fromisoformat(object_history.commits[-1].created_at)
    except ValueError:
        return None

    now = datetime.now().astimezone()
    if latest_commit_time.tzinfo is None:
        latest_commit_time = latest_commit_time.astimezone()
    return max(0.0, (now - latest_commit_time).total_seconds())


def commit_draft_key(object_uuid: str, commit_id: str) -> tuple[str, str]:
    return (str(object_uuid), str(commit_id))


def mark_commit_draft_dirty(object_uuid: str, commit_id: str) -> None:
    _dirty_commit_drafts.add(commit_draft_key(object_uuid, commit_id))


def is_commit_draft_dirty(object_uuid: str, commit_id: str) -> bool:
    return commit_draft_key(object_uuid, commit_id) in _dirty_commit_drafts


def clear_commit_draft_dirty(object_uuid: str, commit_id: str) -> None:
    key = commit_draft_key(object_uuid, commit_id)
    _dirty_commit_drafts.discard(key)
    _suppress_draft_dirty_until.pop(key, None)


def suppress_commit_draft_dirty(
    object_uuid: str,
    commit_id: str,
    seconds: float = 0.5,
) -> None:
    key = commit_draft_key(object_uuid, commit_id)
    _dirty_commit_drafts.discard(key)
    _suppress_draft_dirty_until[key] = monotonic() + seconds


@persistent
def track_commit_draft_dirty(scene: bpy.types.Scene, depsgraph) -> None:
    obj = getattr(bpy.context, "object", None)
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        return

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return

    object_history = load_history_readonly().objects.get(str(object_uuid))
    if object_history is None or object_history.active_commit_id is None:
        return

    active_commit_id = str(object_history.active_commit_id)
    key = commit_draft_key(str(object_uuid), active_commit_id)
    suppressed_until = _suppress_draft_dirty_until.get(key)
    now = monotonic()
    if suppressed_until is not None:
        if now < suppressed_until:
            return
        _suppress_draft_dirty_until.pop(key, None)

    updated_ids = {update.id for update in depsgraph.updates}
    if obj in updated_ids or (obj.data is not None and obj.data in updated_ids):
        mark_commit_draft_dirty(str(object_uuid), active_commit_id)


def show_autocommit_info(context: bpy.types.Context, commit: CommitRecord) -> None:
    scene = getattr(context, "scene", None)
    if not bool(getattr(scene, "nyanneco_object_snapshot_notify_autocommit", True)):
        return
    if bpy.app.background:
        return

    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return

    def draw(self, context: bpy.types.Context) -> None:
        self.layout.label(
            text=iface_format("Snapshot committed: {created_at}", created_at=commit.created_at),
            icon="FILE_TICK",
        )

    try:
        window_manager.popup_menu(draw, title=iface_text("AutoCommit"), icon="INFO")
    except RuntimeError:
        pass


def commit_active_object_for_timer(context: bpy.types.Context) -> CommitRecord | None:
    obj = context.object
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        return None
    if get_linked_object_issue(obj) is not None:
        return None

    previous_mode = obj.mode
    switched_mode = False
    try:
        if obj.mode != "OBJECT":
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode="OBJECT")
            switched_mode = True
        if obj.mode != "OBJECT":
            return None

        repair_duplicate_object_uuids()
        return store_commit(obj, iface_text("Timer auto commit"))
    except (RuntimeError, ValueError):
        return None
    finally:
        if switched_mode and obj.name in bpy.data.objects and previous_mode != "OBJECT":
            try:
                context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode=previous_mode)
            except RuntimeError:
                pass


def any_timer_autocommit_enabled() -> bool:
    return any(timer_autocommit_enabled(scene) for scene in getattr(bpy.data, "scenes", ()))


def timer_autocommit_check() -> float | None:
    global _is_timer_autocommitting
    scene = getattr(bpy.context, "scene", None)
    if not timer_autocommit_enabled(scene):
        if scene is not None:
            _last_timer_autocommit_at_by_scene.pop(scene.name_full, None)
        if not any_timer_autocommit_enabled():
            _last_timer_autocommit_at_by_scene.clear()
            return None
        return TIMER_AUTOCOMMIT_CHECK_INTERVAL

    scene_key = scene.name_full
    now = monotonic()
    interval = timer_autocommit_interval_seconds(scene)
    latest_commit_age = active_object_latest_commit_age_seconds(bpy.context)
    if latest_commit_age is None:
        last_commit_at = _last_timer_autocommit_at_by_scene.setdefault(scene_key, now)
        elapsed = now - last_commit_at
    else:
        elapsed = latest_commit_age

    if elapsed < interval:
        remaining = interval - elapsed
        return max(1.0, min(TIMER_AUTOCOMMIT_CHECK_INTERVAL, remaining))

    if _is_timer_autocommitting:
        return TIMER_AUTOCOMMIT_CHECK_INTERVAL

    _is_timer_autocommitting = True
    try:
        commit = commit_active_object_for_timer(bpy.context)
        if commit is not None:
            _last_timer_autocommit_at_by_scene[scene_key] = monotonic()
            show_autocommit_info(bpy.context, commit)
        else:
            _last_timer_autocommit_at_by_scene[scene_key] = now
    finally:
        _is_timer_autocommitting = False

    return TIMER_AUTOCOMMIT_CHECK_INTERVAL


def duplicate_uuid_repair_timer() -> None:
    global _is_duplicate_uuid_repair_scheduled
    try:
        repair_duplicate_object_uuids()
    except RuntimeError:
        pass
    finally:
        _is_duplicate_uuid_repair_scheduled = False


def schedule_duplicate_uuid_repair() -> None:
    global _is_duplicate_uuid_repair_scheduled
    if _is_duplicate_uuid_repair_scheduled:
        return

    _is_duplicate_uuid_repair_scheduled = True
    register_timer(duplicate_uuid_repair_timer, DUPLICATE_UUID_REPAIR_DELAY)


def show_repository_integrity_warning(warnings: list[str]) -> None:
    if bpy.app.background:
        return

    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return

    def draw(self, context):
        layout = self.layout
        layout.label(text=iface_text("Snapshot repository may be damaged."), icon="ERROR")
        for warning in warnings[:3]:
            layout.label(text=warning)
        layout.label(text=iface_text("Avoid deleting the repository collection manually."))

    window_manager.popup_menu(
        draw,
        title=iface_text("Object Snapshot Repository Warning"),
        icon="ERROR",
    )


def check_repository_integrity_warning() -> None:
    global _last_repository_integrity_check_at
    global _last_repository_integrity_warning_signature

    now = monotonic()
    if now - _last_repository_integrity_check_at < REPOSITORY_INTEGRITY_CHECK_INTERVAL:
        return
    _last_repository_integrity_check_at = now

    warnings = repository_integrity_warnings()
    if not warnings:
        _last_repository_integrity_warning_signature = None
        return

    signature = tuple(warnings)
    if signature == _last_repository_integrity_warning_signature:
        return

    _last_repository_integrity_warning_signature = signature
    show_repository_integrity_warning(warnings)


def snapshot_collection_lock_check() -> float:
    try:
        enforce_snapshot_collection_visibility_lock(getattr(bpy.context, "scene", None))
        check_repository_integrity_warning()
    except RuntimeError:
        pass
    return SNAPSHOT_COLLECTION_LOCK_INTERVAL


@persistent
def enforce_snapshot_collection_on_load(scene: bpy.types.Scene) -> None:
    clear_readonly_history_cache()
    maintain_snapshot_state(create=False, repair_duplicates=True)
    ensure_timer_autocommit_timer()
    ensure_snapshot_collection_lock_timer()


def append_handler(handler_list, handler) -> None:
    if handler not in handler_list:
        handler_list.append(handler)


def remove_handler(handler_list, handler) -> None:
    if handler in handler_list:
        handler_list.remove(handler)


def register_timer(timer_func, first_interval: float) -> None:
    if not bpy.app.timers.is_registered(timer_func):
        bpy.app.timers.register(timer_func, first_interval=first_interval, persistent=True)


def unregister_timer(timer_func) -> None:
    if bpy.app.timers.is_registered(timer_func):
        bpy.app.timers.unregister(timer_func)


def seed_timer_autocommit_scene_clocks() -> None:
    now = monotonic()
    for scene in getattr(bpy.data, "scenes", ()):
        if timer_autocommit_enabled(scene):
            _last_timer_autocommit_at_by_scene.setdefault(scene.name_full, now)
        else:
            _last_timer_autocommit_at_by_scene.pop(scene.name_full, None)


def ensure_timer_autocommit_timer() -> None:
    if any_timer_autocommit_enabled():
        seed_timer_autocommit_scene_clocks()
        register_timer(timer_autocommit_check, TIMER_AUTOCOMMIT_CHECK_INTERVAL)
    else:
        _last_timer_autocommit_at_by_scene.clear()
        unregister_timer(timer_autocommit_check)


def ensure_snapshot_collection_lock_timer() -> None:
    register_timer(snapshot_collection_lock_check, SNAPSHOT_COLLECTION_LOCK_INTERVAL)


def register() -> None:
    append_handler(bpy.app.handlers.load_post, enforce_snapshot_collection_on_load)
    append_handler(bpy.app.handlers.depsgraph_update_post, track_commit_draft_dirty)
    ensure_snapshot_collection_lock_timer()
    ensure_timer_autocommit_timer()


def unregister() -> None:
    global _is_duplicate_uuid_repair_scheduled
    global _last_repository_integrity_check_at
    global _last_repository_integrity_warning_signature
    _is_duplicate_uuid_repair_scheduled = False
    _last_repository_integrity_check_at = 0.0
    _last_repository_integrity_warning_signature = None
    _dirty_commit_drafts.clear()
    _suppress_draft_dirty_until.clear()
    unregister_timer(duplicate_uuid_repair_timer)
    unregister_timer(snapshot_collection_lock_check)
    unregister_timer(timer_autocommit_check)
    remove_handler(bpy.app.handlers.depsgraph_update_post, track_commit_draft_dirty)
    remove_handler(bpy.app.handlers.load_post, enforce_snapshot_collection_on_load)

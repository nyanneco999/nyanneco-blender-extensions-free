ADDON_ID = "nyanneco_object_snapshot"
HISTORY_TEXT_NAME = ".nyanneco_object_snapshot_history.json"
SNAPSHOT_COLLECTION_NAME = ".nyanneco_object_snapshot_commits"
THUMBNAIL_DIR_NAME = ".nyanneco_object_snapshot_thumbnails"
THUMBNAIL_SIZE = 128

OBJECT_UUID_PROP = "nyanneco_object_snapshot_uuid"
SNAPSHOT_MARKER_PROP = "nyanneco_object_snapshot_is_commit"
SNAPSHOT_COMMIT_ID_PROP = "nyanneco_object_snapshot_commit_id"

SUPPORTED_OBJECT_TYPES = {"MESH", "CURVE"}

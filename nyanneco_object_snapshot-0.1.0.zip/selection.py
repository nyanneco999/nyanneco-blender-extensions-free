from __future__ import annotations

SEPARATOR = "\n"
MAIN_SELECTION_PROP = "nyanneco_object_snapshot_selected_commit_ids"
ARCHIVED_SELECTION_PROP = "nyanneco_object_snapshot_selected_archived_commit_ids"


def _selected_ids(scene, prop_name: str) -> set[str]:
    raw_value = getattr(scene, prop_name, "")
    return {commit_id for commit_id in raw_value.split(SEPARATOR) if commit_id}


def _set_selected_ids(scene, prop_name: str, commit_ids) -> None:
    unique_ids = sorted({str(commit_id) for commit_id in commit_ids if commit_id})
    setattr(scene, prop_name, SEPARATOR.join(unique_ids))


def _toggle_selected_id(scene, prop_name: str, commit_id: str) -> bool:
    selected_ids = _selected_ids(scene, prop_name)
    if commit_id in selected_ids:
        selected_ids.remove(commit_id)
        is_selected = False
    else:
        selected_ids.add(commit_id)
        is_selected = True
    _set_selected_ids(scene, prop_name, selected_ids)
    return is_selected


def selected_commit_ids(scene) -> set[str]:
    return _selected_ids(scene, MAIN_SELECTION_PROP)


def set_selected_commit_ids(scene, commit_ids) -> None:
    _set_selected_ids(scene, MAIN_SELECTION_PROP, commit_ids)


def toggle_selected_commit_id(scene, commit_id: str) -> bool:
    return _toggle_selected_id(scene, MAIN_SELECTION_PROP, commit_id)


def clear_selected_commit_ids(scene) -> None:
    setattr(scene, MAIN_SELECTION_PROP, "")


def selected_archived_commit_ids(scene) -> set[str]:
    return _selected_ids(scene, ARCHIVED_SELECTION_PROP)


def set_selected_archived_commit_ids(scene, commit_ids) -> None:
    _set_selected_ids(scene, ARCHIVED_SELECTION_PROP, commit_ids)


def toggle_selected_archived_commit_id(scene, commit_id: str) -> bool:
    return _toggle_selected_id(scene, ARCHIVED_SELECTION_PROP, commit_id)


def clear_selected_archived_commit_ids(scene) -> None:
    setattr(scene, ARCHIVED_SELECTION_PROP, "")

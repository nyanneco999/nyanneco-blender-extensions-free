from __future__ import annotations

import bpy


def snapshot_commit_items(self, context: bpy.types.Context):
    from .constants import OBJECT_UUID_PROP
    from .storage import load_history_readonly

    obj = context.object
    if obj is None:
        return []

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return []

    history = load_history_readonly()
    object_history = history.objects.get(str(object_uuid))
    if object_history is None:
        return []

    items = []
    for commit in object_history.commits:
        label = commit.created_at
        if commit.message:
            label = f"{label} - {commit.message}"
        items.append((commit.commit_id, label, commit.source_object_name))
    return items


def update_timer_autocommit_enabled(self, context: bpy.types.Context) -> None:
    from . import handlers

    handlers.ensure_timer_autocommit_timer()


def register():
    bpy.types.Scene.nyanneco_object_snapshot_selected_commit = bpy.props.EnumProperty(
        name="Snapshot",
        description="Snapshot to restore",
        items=snapshot_commit_items,
    )
    bpy.types.Scene.nyanneco_object_snapshot_timer_autocommit_enabled = bpy.props.BoolProperty(
        name="Timer AutoCommit",
        description="Automatically commit the active object at the configured interval",
        default=False,
        update=update_timer_autocommit_enabled,
    )
    bpy.types.Scene.nyanneco_object_snapshot_timer_autocommit_minutes = bpy.props.IntProperty(
        name="Timer Minutes",
        description="Minutes between timer AutoCommit snapshots",
        default=10,
        min=1,
        soft_max=120,
    )
    bpy.types.Scene.nyanneco_object_snapshot_notify_autocommit = bpy.props.BoolProperty(
        name="Popup Notification on AutoCommit",
        description="Show a popup notification when AutoCommit creates a snapshot",
        default=True,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_older_commits = bpy.props.BoolProperty(
        name="Show Older Snapshots",
        description="Show snapshots older than the latest five entries",
        default=False,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_archived_commits = bpy.props.BoolProperty(
        name="Archived Snapshots",
        description="Show archived snapshots in the history list",
        default=False,
    )
    bpy.types.Scene.nyanneco_object_snapshot_selected_commit_ids = bpy.props.StringProperty(
        name="Selected Snapshot IDs",
        description="Internal selection state for batch snapshot operations",
        default="",
        options={"HIDDEN"},
    )
    bpy.types.Scene.nyanneco_object_snapshot_selected_archived_commit_ids = (
        bpy.props.StringProperty(
            name="Selected Archived Snapshot IDs",
            description="Internal selection state for archived batch snapshot operations",
            default="",
            options={"HIDDEN"},
        )
    )
    bpy.types.Scene.nyanneco_object_snapshot_confirm_archive = bpy.props.BoolProperty(
        name="Confirm Archive Operations",
        description="Show a confirmation dialog before archiving snapshots",
        default=True,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_delete_operations = bpy.props.BoolProperty(
        name="Delete Operations",
        description="Show destructive snapshot deletion actions",
        default=False,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_settings_card = bpy.props.BoolProperty(
        name="Settings",
        description="Show snapshot settings card",
        default=True,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_history_list = bpy.props.BoolProperty(
        name="History List",
        description="Show snapshot history list",
        default=True,
    )
    bpy.types.Scene.nyanneco_object_snapshot_show_thumbnail_settings = bpy.props.BoolProperty(
        name="Thumbnail Settings",
        description="Show snapshot thumbnail settings",
        default=False,
    )
    bpy.types.Scene.nyanneco_object_snapshot_hide_thumbnails = bpy.props.BoolProperty(
        name="Hide Thumbnails",
        description="Hide snapshot thumbnails in the history list",
        default=False,
    )


def unregister():
    del bpy.types.Scene.nyanneco_object_snapshot_hide_thumbnails
    del bpy.types.Scene.nyanneco_object_snapshot_show_thumbnail_settings
    del bpy.types.Scene.nyanneco_object_snapshot_show_history_list
    del bpy.types.Scene.nyanneco_object_snapshot_show_settings_card
    del bpy.types.Scene.nyanneco_object_snapshot_show_delete_operations
    del bpy.types.Scene.nyanneco_object_snapshot_confirm_archive
    del bpy.types.Scene.nyanneco_object_snapshot_selected_archived_commit_ids
    del bpy.types.Scene.nyanneco_object_snapshot_selected_commit_ids
    del bpy.types.Scene.nyanneco_object_snapshot_show_archived_commits
    del bpy.types.Scene.nyanneco_object_snapshot_show_older_commits
    del bpy.types.Scene.nyanneco_object_snapshot_notify_autocommit
    del bpy.types.Scene.nyanneco_object_snapshot_timer_autocommit_minutes
    del bpy.types.Scene.nyanneco_object_snapshot_timer_autocommit_enabled
    del bpy.types.Scene.nyanneco_object_snapshot_selected_commit

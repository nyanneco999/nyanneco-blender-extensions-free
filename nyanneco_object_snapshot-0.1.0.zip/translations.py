from __future__ import annotations

import bpy

_CONTEXTS = ("*", "Operator", "Property", "UI")

_JA_MESSAGES = {
    "Object context menu": "オブジェクトコンテキストメニュー",
    "Object-level snapshot history for mesh and curve objects.": (
        "メッシュ・カーブオブジェクト向けのオブジェクト単位スナップショット履歴"
    ),
    "Object Snapshot": "オブジェクトスナップショット",
    "Commit Object Snapshot": "オブジェクトスナップショットをコミット",
    "Store the active object's current state as a hidden snapshot": (
        "アクティブオブジェクトの現在状態を非表示スナップショットとして保存します"
    ),
    "Message": "メッセージ",
    "Short note for this snapshot": "このスナップショット用の短いメモ",
    "Restore Object Snapshot": "オブジェクトスナップショットをリストア",
    "Restore the active object to the selected snapshot": (
        "アクティブオブジェクトを選択したスナップショットへ戻します"
    ),
    "Discard Snapshot Draft": "作業途中を破棄",
    "Discard the temporary draft for the selected snapshot": (
        "選択したスナップショットの作業途中データを破棄します"
    ),
    "Commit ID": "コミットID",
    "AutoCommit": "自動コミット",
    "Timer AutoCommit": "タイマー自動コミット",
    "Automatically commit the active object at the configured interval": (
        "設定した間隔でアクティブオブジェクトを自動コミットします"
    ),
    "Timer Minutes": "タイマー分数",
    "Minutes between timer AutoCommit snapshots": (
        "タイマー自動コミットを行う間隔を分単位で指定します"
    ),
    "Popup Notification on AutoCommit": "自動コミット時にポップアップ通知する",
    "Show a popup notification when AutoCommit creates a snapshot": (
        "自動コミットでスナップショットを作成したときにポップアップ通知を表示します"
    ),
    "Object Snapshot History": "オブジェクトスナップショット履歴",
    "Show snapshots for the active object": (
        "アクティブオブジェクトのスナップショットを表示します"
    ),
    "Delete Object Snapshot": "オブジェクトスナップショットを削除",
    "Delete the selected object snapshot": "選択したオブジェクトスナップショットを削除します",
    "Archive Object Snapshot": "オブジェクトスナップショットをアーカイブ",
    "Move the selected snapshot out of the main history list": (
        "選択したスナップショットを通常の履歴リストからアーカイブへ移動します"
    ),
    "Unarchive Object Snapshot": "オブジェクトスナップショットをアーカイブから戻す",
    "Return the selected snapshot to the main history list": (
        "選択したスナップショットを通常の履歴リストへ戻します"
    ),
    "Toggle Snapshot Selection": "スナップショットのチェックを切り替え",
    "Toggle this snapshot for batch operations": (
        "一括操作用にこのスナップショットのチェックを切り替えます"
    ),
    "Select Visible Snapshots": "表示中のスナップショットをすべてチェック",
    "Select all currently visible snapshots for batch operations": (
        "現在表示されているスナップショットを一括操作用にすべてチェックします"
    ),
    "Clear Snapshot Selection": "スナップショットのチェックを解除",
    "Clear all checked snapshots": "チェックされているスナップショットをすべて解除します",
    "Select Visible Archived Snapshots": "表示中のアーカイブをすべてチェック",
    "Select all currently visible archived snapshots for batch operations": (
        "現在表示されているアーカイブ済みスナップショットを一括操作用にすべてチェックします"
    ),
    "Clear Archived Snapshot Selection": "アーカイブのチェックを解除",
    "Clear all checked archived snapshots": (
        "チェックされているアーカイブ済みスナップショットをすべて解除します"
    ),
    "Archive Selected Snapshots": "チェック済みスナップショットをアーカイブ",
    "Archive all checked snapshots": ("チェックされているスナップショットをすべてアーカイブします"),
    "Unarchive Selected Snapshots": "チェック済みアーカイブを復帰",
    "Return all checked archived snapshots to the main history list": (
        "チェックされているアーカイブ済みスナップショットを通常リストへ戻します"
    ),
    "Delete Selected Snapshots": "チェック済みスナップショットを削除",
    "Delete all checked snapshots": "チェックされているスナップショットをすべて削除します",
    "Delete Selected Archived Snapshots": "チェック済みアーカイブを削除",
    "Delete all checked archived snapshots": (
        "チェックされているアーカイブ済みスナップショットをすべて削除します"
    ),
    "Edit Snapshot Message": "スナップショットメッセージを編集",
    "Edit the selected snapshot message": "選択したスナップショットのメッセージを編集します",
    "Branch Object Snapshot": "オブジェクトスナップショットをブランチ",
    "Create a new editable branch object from the selected snapshot": (
        "選択したスナップショットから編集可能な新規ブランチオブジェクトを作成します"
    ),
    "Merge Branch Object History": "ブランチ履歴をマージ",
    "Merge this branch object's new history back to its source object": (
        "このブランチオブジェクトの新しい履歴をブランチ元へマージします"
    ),
    "Delete All Object Snapshots": "すべてのオブジェクトスナップショットを削除",
    "Delete all snapshots for the active object": (
        "アクティブオブジェクトのすべてのスナップショットを削除します"
    ),
    "Delete All History": "すべての履歴を削除",
    "Delete all snapshot history for all objects": (
        "すべてのオブジェクトのスナップショット履歴を削除します"
    ),
    "Delete Selected Object History": "選択オブジェクトの全履歴削除",
    "Delete all snapshot history for the selected object": (
        "選択オブジェクトのすべてのスナップショット履歴を削除します"
    ),
    "Delete Repository": "リポジトリを削除",
    "Delete the snapshot repository and clear object snapshot IDs": (
        "スナップショットリポジトリを削除し、オブジェクト側のスナップショットIDを消去します"
    ),
    "Repair Snapshot Repository": "スナップショットリポジトリを復元",
    "Recreate the snapshot repository collection and relink snapshot objects": (
        "スナップショットリポジトリ用コレクションを作り直し、Snapshot Objectを再リンクします"
    ),
    "Snapshot": "スナップショット",
    "Snapshot to restore": "リストアするスナップショット",
    "Show Older Snapshots": "古いスナップショットを表示",
    "Show snapshots older than the latest five entries": (
        "最新5件より古いスナップショットを表示します"
    ),
    "Repository Operations": "リポジトリの操作",
    "Show snapshot repository maintenance actions": (
        "スナップショットリポジトリのメンテナンス操作を表示します"
    ),
    "Delete Operations": "削除操作",
    "Show destructive snapshot deletion actions": ("スナップショットの削除操作を表示します"),
    "Show Delete Operations": "削除操作を表示",
    "Settings": "設定",
    "Branch": "ブランチ",
    "Merge Branch to Source": "ブランチ元へマージ",
    "Show snapshot settings card": "スナップショット設定カードを表示します",
    "History List": "履歴リスト",
    "Show snapshot history list": "スナップショット履歴リストを表示します",
    "Timer Settings": "タイマー設定",
    "Thumbnail Settings": "サムネイル設定",
    "Show snapshot thumbnail settings": "スナップショットサムネイル設定を表示します",
    "Regenerate Selected Object Thumbnails": "選択オブジェクトの履歴サムネイル再生成",
    "Regenerate thumbnail cache for the selected object's history": (
        "選択オブジェクトの履歴サムネイルキャッシュを再生成します"
    ),
    "Hide Thumbnails": "サムネイルを非表示",
    "Hide snapshot thumbnails in the history list": (
        "履歴リスト内のスナップショットサムネイルを非表示にします"
    ),
    "Confirm Archive Operations": "アーカイブ実行時に確認する",
    "Show a confirmation dialog before archiving snapshots": (
        "スナップショットをアーカイブする前に確認ダイアログを表示します"
    ),
    "Dialog": "ダイアログ",
    "Older Snapshots": "古いスナップショット",
    "Archived Snapshots": "アーカイブ済みスナップショット",
    "Archived": "アーカイブ済み",
    "Checked": "チェック",
    "Archived Checked": "アーカイブチェック",
    "Current": "現在",
    "ID": "ID",
    "Draft": "作業途中あり",
    "(no message)": "（メッセージなし）",
    "Select a mesh or curve object.": "メッシュまたはカーブオブジェクトを選択してください。",
    "Object Snapshot actions are available in Object Mode only.": (
        "Object Snapshotの操作はObject Modeでのみ利用できます。"
    ),
    "Checking copied object state...": "コピー状態を確認中...",
    "No snapshots for this object.": "このオブジェクトにはスナップショットがありません。",
    "External linked objects are not supported.": (
        "外部リンクされたオブジェクトは対応していません。"
    ),
    "Objects using external linked data are not supported.": (
        "外部リンクデータを使用するオブジェクトは対応していません。"
    ),
    "Linked duplicate/shared-data objects are not supported.": (
        "リンク複製または共有データのオブジェクトは対応していません。"
    ),
    "Snapshot committed: {created_at}": "スナップショットをコミットしました: {created_at}",
    "Timer auto commit": "タイマー自動コミット",
    "This feature is available in the paid version.": ("この機能は有料版で利用できます。"),
    "Free version limit reached: {count} commits per object.": (
        "無料版の上限に達しました: 1オブジェクトにつき {count} コミットまでです。"
    ),
    "Free version limit reached: {count} commits per scene.": (
        "無料版の上限に達しました: シーン全体で {count} コミットまでです。"
    ),
    "The selected object has no snapshot history.": (
        "選択中のオブジェクトにはスナップショット履歴がありません。"
    ),
    "Select a snapshot to restore.": "リストアするスナップショットを選択してください。",
    "Snapshot history entry was not found.": "スナップショット履歴が見つかりませんでした。",
    "Auto snapshot before restore": "リストア前の自動スナップショット",
    "Missing materials were restored as empty slots:": (
        "見つからないマテリアルは空スロットとして復元しました:"
    ),
    "Missing references were cleared:": ("復元できない参照は空にしました:"),
    "Snapshot restored: {created_at}": "スナップショットをリストアしました: {created_at}",
    "Snapshot draft was not found.": "作業途中データが見つかりませんでした。",
    "Snapshot draft discarded.": "作業途中データを破棄しました。",
    "Select a snapshot to branch.": "ブランチするスナップショットを選択してください。",
    "Branched from {source_object_name}": "{source_object_name} からブランチ",
    "Snapshot branched as: {object_name}": ("スナップショットをブランチしました: {object_name}"),
    "The selected object is not a branched snapshot object.": (
        "選択オブジェクトはブランチされたスナップショットオブジェクトではありません。"
    ),
    "Branch source object was not found.": "ブランチ元オブジェクトが見つかりません。",
    "Branch source history was not found.": "ブランチ元履歴が見つかりません。",
    "Merged {merged_count} new snapshots into {object_name}.": (
        "{object_name} に新規スナップショット {merged_count} 件をマージしました。"
    ),
    "Select a snapshot to delete.": "削除するスナップショットを選択してください。",
    "Snapshot deleted: {created_at}": "スナップショットを削除しました: {created_at}",
    "Snapshot archived.": "スナップショットをアーカイブしました。",
    "Snapshot unarchived.": "スナップショットをアーカイブから戻しました。",
    "No snapshots are checked.": "チェックされているスナップショットがありません。",
    "No archived snapshots are checked.": (
        "チェックされているアーカイブ済みスナップショットがありません。"
    ),
    "Archived {count} snapshots.": "{count} 件のスナップショットをアーカイブしました。",
    "Unarchived {count} snapshots.": ("{count} 件のスナップショットをアーカイブから戻しました。"),
    "Deleted {count} checked snapshots.": (
        "チェック済みスナップショットを {count} 件削除しました。"
    ),
    "Deleted {count} checked archived snapshots.": (
        "チェック済みアーカイブを {count} 件削除しました。"
    ),
    "Select a snapshot to edit.": "編集するスナップショットを選択してください。",
    "Snapshot message updated: {created_at}": (
        "スナップショットメッセージを更新しました: {created_at}"
    ),
    "No snapshot history to delete.": "削除するスナップショット履歴がありません。",
    "Deleted {count} snapshots.": "{count} 件のスナップショットを削除しました。",
    "Deleted {count} selected object history entries.": (
        "選択オブジェクトの履歴を {count} 件削除しました。"
    ),
    "Deleted {count} history entries.": "{count} 件の履歴を削除しました。",
    "No snapshot repository data to delete.": (
        "削除するスナップショットリポジトリデータがありません。"
    ),
    "Snapshot repository deleted: {count} history entries.": (
        "スナップショットリポジトリを削除しました: {count} 件の履歴"
    ),
    "Object Snapshot Repository Warning": "Object Snapshotリポジトリ警告",
    "Snapshot repository may be damaged.": (
        "スナップショットリポジトリが破損している可能性があります。"
    ),
    "Snapshot repository collection is missing.": (
        "スナップショットリポジトリ用コレクションが見つかりません。"
    ),
    "Snapshot repository is missing {count} snapshot objects.": (
        "スナップショットリポジトリ内のSnapshot Objectが {count} 件見つかりません。"
    ),
    "Snapshot repository has {count} exposed snapshot objects.": (
        "Snapshot Objectが {count} 件リポジトリ外に露出しています。"
    ),
    "Snapshot actions are disabled until the repository is repaired.": (
        "リポジトリを復元するまでスナップショット操作は無効です。"
    ),
    "Some snapshot contents are missing.": "一部のスナップショット内容が失われています。",
    "Snapshot repository repaired: {count} snapshot objects relinked.": (
        "スナップショットリポジトリを復元しました: {count} 件のSnapshot Objectを再リンク"
    ),
    "Snapshot repository repair incomplete: {count} snapshot objects are missing.": (
        "スナップショットリポジトリの復元は不完全です: Snapshot Objectが {count} 件見つかりません。"
    ),
    "Avoid deleting the repository collection manually.": (
        "リポジトリ用コレクションを手動削除しないでください。"
    ),
    "No thumbnails were regenerated.": "再生成されたサムネイルはありません。",
    "Regenerated {count} thumbnails.": "{count} 件のサムネイルを再生成しました。",
    "Delete all history for the selected object?": ("選択オブジェクトの全履歴を削除しますか？"),
    "Really delete all history for the selected object?": (
        "本当に選択オブジェクトの全履歴を削除しますか？"
    ),
    "Delete all history for all objects?": "すべてのオブジェクトの全履歴を削除しますか？",
    "Really delete all history for all objects?": (
        "本当にすべてのオブジェクトの全履歴を削除しますか？"
    ),
    "Delete the entire snapshot repository?": ("スナップショットリポジトリ全体を削除しますか？"),
    "Really delete the entire snapshot repository?": (
        "本当にスナップショットリポジトリ全体を削除しますか？"
    ),
    "Discard this draft?": "この作業途中データを破棄しますか？",
    "Really discard this draft?": "本当にこの作業途中データを破棄しますか？",
    "Delete checked snapshots?": "チェック済みスナップショットを削除しますか？",
    "Really delete checked snapshots?": ("本当にチェック済みスナップショットを削除しますか？"),
    "Delete checked archived snapshots?": ("チェック済みアーカイブを削除しますか？"),
    "Really delete checked archived snapshots?": ("本当にチェック済みアーカイブを削除しますか？"),
    "Merge this branch back to its source object?": (
        "このブランチをブランチ元オブジェクトへマージしますか？"
    ),
    "Really merge this branch and remove the branch object?": (
        "本当にこのブランチをマージして、ブランチオブジェクトを削除しますか？"
    ),
    "A second confirmation will be required.": "次にもう一度確認します。",
    "This action cannot be undone from the add-on.": ("この操作はアドオン側からは元に戻せません。"),
}

TRANSLATIONS = {
    "ja_JP": {
        (context, source): translated
        for source, translated in _JA_MESSAGES.items()
        for context in _CONTEXTS
    },
}


def iface_text(message: str) -> str:
    return bpy.app.translations.pgettext_iface(message)


def iface_format(message: str, **kwargs: object) -> str:
    return iface_text(message).format(**kwargs)


def register() -> None:
    bpy.app.translations.register(__name__, TRANSLATIONS)


def unregister() -> None:
    bpy.app.translations.unregister(__name__)

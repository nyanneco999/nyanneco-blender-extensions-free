from __future__ import annotations

from pathlib import Path

import bpy
import bpy.utils.previews

_preview_collection: bpy.utils.previews.ImagePreviewCollection | None = None
_thumbnail_icon_cache: dict[str, int] = {}
_missing_thumbnail_paths: set[str] = set()
CURRENT_SNAPSHOT_ICON_KEY = "nyanneco_current_snapshot_icon"
CURRENT_SNAPSHOT_ICON_PATH = Path(__file__).with_name("icons") / "current_snapshot.png"
DRAFT_SNAPSHOT_ICON_KEY = "nyanneco_draft_snapshot_icon"
DRAFT_SNAPSHOT_ICON_PATH = Path(__file__).with_name("icons") / "draft_snapshot.png"


def get_preview_collection() -> bpy.utils.previews.ImagePreviewCollection:
    global _preview_collection
    if _preview_collection is None:
        _preview_collection = bpy.utils.previews.new()
    return _preview_collection


def get_thumbnail_icon_id(thumbnail_path: str | None) -> int:
    if not thumbnail_path:
        return 0

    path = Path(bpy.path.abspath(thumbnail_path))
    cache_key = str(path)
    if cache_key in _thumbnail_icon_cache:
        return _thumbnail_icon_cache[cache_key]
    if cache_key in _missing_thumbnail_paths:
        return 0

    if not path.exists():
        _missing_thumbnail_paths.add(cache_key)
        return 0

    collection = get_preview_collection()
    key = f"thumbnail:{path}"
    if key not in collection:
        collection.load(key, str(path), "IMAGE")
    icon_id = collection[key].icon_id
    _thumbnail_icon_cache[cache_key] = icon_id
    return icon_id


def get_current_snapshot_icon_id() -> int:
    collection = get_preview_collection()
    key = CURRENT_SNAPSHOT_ICON_KEY
    if key not in collection:
        collection.load(key, str(CURRENT_SNAPSHOT_ICON_PATH), "IMAGE")
    return collection[key].icon_id


def get_draft_snapshot_icon_id() -> int:
    collection = get_preview_collection()
    key = DRAFT_SNAPSHOT_ICON_KEY
    if key not in collection:
        collection.load(key, str(DRAFT_SNAPSHOT_ICON_PATH), "IMAGE")
    return collection[key].icon_id


def clear_preview_cache() -> None:
    global _preview_collection
    _thumbnail_icon_cache.clear()
    _missing_thumbnail_paths.clear()
    if _preview_collection is not None:
        bpy.utils.previews.remove(_preview_collection)
        _preview_collection = None


def register() -> None:
    get_preview_collection()


def unregister() -> None:
    clear_preview_cache()

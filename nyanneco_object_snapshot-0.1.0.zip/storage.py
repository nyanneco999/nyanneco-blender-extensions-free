from __future__ import annotations

import copy
import json
import shutil
import tempfile
import uuid
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from time import monotonic

import bpy
from mathutils import Vector

from .constants import (
    HISTORY_TEXT_NAME,
    OBJECT_UUID_PROP,
    SNAPSHOT_COLLECTION_NAME,
    SNAPSHOT_COMMIT_ID_PROP,
    SNAPSHOT_MARKER_PROP,
    SUPPORTED_OBJECT_TYPES,
    THUMBNAIL_DIR_NAME,
    THUMBNAIL_SIZE,
)
from .features import commit_limit_issue
from .models import CommitRecord, HistoryDocument, ObjectHistory
from .translations import iface_format

SNAPSHOT_INTERNAL_PROPS = {
    OBJECT_UUID_PROP,
    SNAPSHOT_COMMIT_ID_PROP,
    SNAPSHOT_MARKER_PROP,
    "selection_order",
}

HISTORY_READONLY_CACHE_SECONDS = 0.25
_history_readonly_cache: HistoryDocument | None = None
_history_readonly_cache_at = 0.0

RNA_COPY_EXCLUDED_PROPS = {
    "bl_rna",
    "rna_type",
}

ID_COLLECTIONS_BY_RNA = {
    "Action": "actions",
    "Armature": "armatures",
    "Camera": "cameras",
    "Collection": "collections",
    "Curve": "curves",
    "GreasePencil": "grease_pencils",
    "Image": "images",
    "Key": "shape_keys",
    "Lattice": "lattices",
    "Light": "lights",
    "Material": "materials",
    "Mesh": "meshes",
    "MovieClip": "movieclips",
    "NodeTree": "node_groups",
    "Object": "objects",
    "ParticleSettings": "particles",
    "Scene": "scenes",
    "Sound": "sounds",
    "Texture": "textures",
    "Text": "texts",
    "VectorFont": "fonts",
    "Volume": "volumes",
    "World": "worlds",
}


@dataclass(slots=True)
class RestoreResult:
    obj: bpy.types.Object
    missing_material_names: list[str]
    missing_reference_names: list[str]


@dataclass(slots=True)
class ForkResult:
    obj: bpy.types.Object
    commit: CommitRecord
    missing_material_names: list[str]


@dataclass(slots=True)
class UUIDRepairResult:
    reassigned_object_names: list[str]
    removed_snapshot_names: list[str]


@dataclass(slots=True)
class RepositoryDeleteResult:
    removed_commit_count: int
    removed_snapshot_object_count: int
    removed_collection_count: int
    cleared_object_count: int
    removed_history_text: bool


@dataclass(slots=True)
class RepositoryIntegrityStatus:
    has_history_text: bool
    snapshot_record_count: int
    collection_missing: bool
    missing_snapshot_object_names: list[str]
    unlinked_snapshot_object_names: list[str]

    @property
    def is_damaged(self) -> bool:
        return self.snapshot_record_count > 0 and (
            self.collection_missing
            or bool(self.missing_snapshot_object_names)
            or bool(self.unlinked_snapshot_object_names)
        )

    @property
    def blocks_ui(self) -> bool:
        return self.snapshot_record_count > 0 and (
            self.collection_missing or bool(self.unlinked_snapshot_object_names)
        )

    @property
    def can_repair(self) -> bool:
        return self.snapshot_record_count > 0 and (
            self.collection_missing or bool(self.unlinked_snapshot_object_names)
        )

    @property
    def is_unrecoverable(self) -> bool:
        return bool(self.missing_snapshot_object_names)


@dataclass(slots=True)
class RepositoryRepairResult:
    repaired_collection: bool
    relinked_snapshot_count: int
    missing_snapshot_object_names: list[str]


@dataclass(slots=True)
class ThumbnailRegenerateResult:
    generated_count: int
    missing_snapshot_count: int


@dataclass(slots=True)
class ForkMergeResult:
    target_object: bpy.types.Object
    merged_commit_count: int
    reused_commit_count: int
    removed_branch_commit_count: int


def local_timestamp() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def new_id() -> str:
    return uuid.uuid4().hex


def get_object_uuid(obj: bpy.types.Object) -> str:
    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        object_uuid = new_id()
        obj[OBJECT_UUID_PROP] = object_uuid
    return str(object_uuid)


def assign_new_object_uuid(obj: bpy.types.Object) -> str:
    object_uuid = new_id()
    obj[OBJECT_UUID_PROP] = object_uuid
    return object_uuid


def get_linked_object_issue(obj: bpy.types.Object) -> str | None:
    if obj.library is not None:
        return "External linked objects are not supported."
    if obj.data is not None and obj.data.library is not None:
        return "Objects using external linked data are not supported."
    if obj.data is not None and obj.data.users > 1:
        return "Linked duplicate/shared-data objects are not supported."
    return None


def is_snapshot_object(obj: bpy.types.Object) -> bool:
    return bool(obj.get(SNAPSHOT_MARKER_PROP))


def get_history_text() -> bpy.types.Text:
    text = bpy.data.texts.get(HISTORY_TEXT_NAME)
    if text is None:
        text = bpy.data.texts.new(HISTORY_TEXT_NAME)
        text.use_fake_user = True
        text.write(json.dumps(HistoryDocument.empty().to_dict(), indent=2))
    return text


def cache_readonly_history(history: HistoryDocument) -> None:
    global _history_readonly_cache
    global _history_readonly_cache_at
    _history_readonly_cache = history
    _history_readonly_cache_at = monotonic()


def clear_readonly_history_cache() -> None:
    global _history_readonly_cache
    global _history_readonly_cache_at
    _history_readonly_cache = None
    _history_readonly_cache_at = 0.0


def load_history() -> HistoryDocument:
    text = get_history_text()
    content = text.as_string().strip()
    if not content:
        history = HistoryDocument.empty()
        cache_readonly_history(history)
        return history
    try:
        history = HistoryDocument.from_dict(json.loads(content))
    except (AttributeError, TypeError, ValueError, KeyError):
        backup_name = f"{HISTORY_TEXT_NAME}.broken.{new_id()[:8]}"
        backup = bpy.data.texts.new(backup_name)
        backup.write(content)
        text.clear()
        history = HistoryDocument.empty()
        text.write(json.dumps(history.to_dict(), indent=2))
    cache_readonly_history(history)
    return history


def load_history_readonly() -> HistoryDocument:
    if (
        _history_readonly_cache is not None
        and monotonic() - _history_readonly_cache_at < HISTORY_READONLY_CACHE_SECONDS
    ):
        return _history_readonly_cache

    text = bpy.data.texts.get(HISTORY_TEXT_NAME)
    if text is None:
        history = HistoryDocument.empty()
        cache_readonly_history(history)
        return history

    content = text.as_string().strip()
    if not content:
        history = HistoryDocument.empty()
        cache_readonly_history(history)
        return history
    try:
        history = HistoryDocument.from_dict(json.loads(content))
    except (AttributeError, TypeError, ValueError, KeyError):
        history = HistoryDocument.empty()
    cache_readonly_history(history)
    return history


def has_history_entries() -> bool:
    if bpy.data.texts.get(HISTORY_TEXT_NAME) is None:
        return False
    return bool(load_history_readonly().objects)


def save_history(history: HistoryDocument) -> None:
    text = get_history_text()
    text.clear()
    text.write(json.dumps(history.to_dict(), indent=2, ensure_ascii=False))
    cache_readonly_history(history)


def get_snapshot_collection() -> bpy.types.Collection:
    if not hasattr(bpy.data, "collections"):
        msg = "bpy.data.collections is not available while Blender is enabling the add-on."
        raise RuntimeError(msg)

    collection = bpy.data.collections.get(SNAPSHOT_COLLECTION_NAME)
    if collection is None:
        collection = bpy.data.collections.new(SNAPSHOT_COLLECTION_NAME)
        bpy.context.scene.collection.children.link(collection)
    lock_snapshot_collection(collection)
    lock_snapshot_layer_collections()
    return collection


def lock_snapshot_collection_properties(collection: bpy.types.Collection) -> None:
    if not collection.hide_viewport:
        collection.hide_viewport = True
    if not collection.hide_render:
        collection.hide_render = True
    if hasattr(collection, "hide_select") and not collection.hide_select:
        collection.hide_select = True


def lock_snapshot_collection(collection: bpy.types.Collection) -> None:
    lock_snapshot_collection_properties(collection)

    for obj in collection.objects:
        hide_snapshot_object(obj)


def find_layer_collection(
    layer_collection: bpy.types.LayerCollection,
    collection: bpy.types.Collection,
) -> bpy.types.LayerCollection | None:
    if layer_collection.collection == collection:
        return layer_collection

    for child in layer_collection.children:
        found = find_layer_collection(child, collection)
        if found is not None:
            return found
    return None


def lock_snapshot_layer_collections() -> None:
    if not hasattr(bpy.data, "collections") or not hasattr(bpy.data, "scenes"):
        return

    collection = bpy.data.collections.get(SNAPSHOT_COLLECTION_NAME)
    if collection is None:
        return

    for scene in bpy.data.scenes:
        lock_snapshot_layer_collections_for_scene(scene, collection)


def lock_snapshot_layer_collections_for_scene(
    scene: bpy.types.Scene,
    collection: bpy.types.Collection,
) -> None:
    for view_layer in scene.view_layers:
        layer_collection = find_layer_collection(view_layer.layer_collection, collection)
        if layer_collection is None:
            continue

        if not layer_collection.exclude:
            layer_collection.exclude = True
        if not layer_collection.hide_viewport:
            layer_collection.hide_viewport = True


def enforce_snapshot_collection_lock(create: bool = False) -> None:
    if not hasattr(bpy.data, "collections"):
        return

    collection = bpy.data.collections.get(SNAPSHOT_COLLECTION_NAME)
    if collection is None and create:
        collection = get_snapshot_collection()
    if collection is None:
        return

    lock_snapshot_collection(collection)
    lock_snapshot_layer_collections()


def enforce_snapshot_collection_visibility_lock(scene: bpy.types.Scene | None = None) -> None:
    if not hasattr(bpy.data, "collections"):
        return

    collection = bpy.data.collections.get(SNAPSHOT_COLLECTION_NAME)
    if collection is None:
        return

    lock_snapshot_collection_properties(collection)
    target_scene = scene if scene is not None else getattr(bpy.context, "scene", None)
    if target_scene is not None:
        lock_snapshot_layer_collections_for_scene(target_scene, collection)


def get_thumbnail_dir() -> Path:
    if bpy.data.filepath:
        base_dir = Path(bpy.path.abspath("//"))
    else:
        base_dir = Path(tempfile.gettempdir()) / "nyanneco_object_snapshot"

    thumbnail_dir = base_dir / THUMBNAIL_DIR_NAME
    thumbnail_dir.mkdir(parents=True, exist_ok=True)
    return thumbnail_dir


def get_thumbnail_path(commit_id: str) -> Path:
    return get_thumbnail_dir() / f"{commit_id}.png"


def get_object_bounds(obj: bpy.types.Object) -> tuple[Vector, float]:
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    center = sum(corners, Vector()) / len(corners)
    max_dim = max((corner - center).length for corner in corners) * 2
    return center, max(max_dim, 0.1)


def look_at(camera: bpy.types.Object, target: Vector) -> None:
    direction = target - camera.location
    camera.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()


def render_thumbnail(snapshot: bpy.types.Object, commit_id: str) -> str | None:
    thumbnail_path = get_thumbnail_path(commit_id)
    scene = bpy.data.scenes.new(f".nyanneco_thumbnail_scene_{commit_id[:8]}")
    camera_data = bpy.data.cameras.new(f".nyanneco_thumbnail_camera_{commit_id[:8]}")
    camera = bpy.data.objects.new(camera_data.name, camera_data)
    render_obj = snapshot.copy()
    scene_name = scene.name
    camera_name = camera.name
    camera_data_name = camera_data.name
    render_obj_name = render_obj.name

    try:
        scene.render.engine = "BLENDER_WORKBENCH"
        scene.render.resolution_x = THUMBNAIL_SIZE
        scene.render.resolution_y = THUMBNAIL_SIZE
        scene.render.film_transparent = True
        scene.render.filepath = str(thumbnail_path)
        scene.collection.objects.link(render_obj)
        scene.collection.objects.link(camera)

        render_obj.hide_viewport = False
        render_obj.hide_render = False
        render_obj.hide_select = False
        render_obj.hide_set(False)

        center, max_dim = get_object_bounds(render_obj)
        camera.data.type = "ORTHO"
        camera.data.ortho_scale = max_dim * 1.35
        view_direction = Vector((1.2, -1.4, 0.8)).normalized()
        camera.location = center + view_direction * max_dim * 2.5
        look_at(camera, center)
        scene.camera = camera

        with bpy.context.temp_override(scene=scene):
            bpy.ops.render.render(write_still=True)
    except Exception:
        return None
    finally:
        existing_render_obj = bpy.data.objects.get(render_obj_name)
        if existing_render_obj is not None:
            bpy.data.objects.remove(existing_render_obj, do_unlink=True)
        existing_camera = bpy.data.objects.get(camera_name)
        if existing_camera is not None:
            bpy.data.objects.remove(existing_camera, do_unlink=True)
        existing_camera_data = bpy.data.cameras.get(camera_data_name)
        if existing_camera_data is not None:
            bpy.data.cameras.remove(existing_camera_data, do_unlink=True)
        existing_scene = bpy.data.scenes.get(scene_name)
        if existing_scene is not None:
            bpy.data.scenes.remove(existing_scene, do_unlink=True)

    return str(thumbnail_path) if thumbnail_path.exists() else None


def thumbnail_path_exists(thumbnail_path: str | None) -> bool:
    if not thumbnail_path:
        return False
    return Path(bpy.path.abspath(thumbnail_path)).exists()


def thumbnail_cache_is_current(thumbnail_path: str | None, commit_id: str) -> bool:
    if not thumbnail_path_exists(thumbnail_path):
        return False

    path = Path(bpy.path.abspath(thumbnail_path))
    current_path = get_thumbnail_path(commit_id)
    return str(path).casefold() == str(current_path).casefold()


def regenerate_commit_thumbnail(commit: CommitRecord) -> bool:
    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    if snapshot is None:
        return False

    thumbnail_path = render_thumbnail(snapshot, commit.commit_id)
    if thumbnail_path is None:
        return False

    commit.thumbnail_path = thumbnail_path
    return True


def regenerate_thumbnail_cache(
    object_uuid: str | None = None,
    force: bool = False,
) -> ThumbnailRegenerateResult:
    history = load_history()
    generated_count = 0
    missing_snapshot_count = 0
    changed = False

    if object_uuid is None:
        object_histories = list(history.objects.values())
    else:
        object_history = history.objects.get(object_uuid)
        object_histories = [] if object_history is None else [object_history]

    for object_history in object_histories:
        for commit in object_history.commits:
            if not force and thumbnail_cache_is_current(commit.thumbnail_path, commit.commit_id):
                continue

            if regenerate_commit_thumbnail(commit):
                generated_count += 1
                changed = True
            else:
                missing_snapshot_count += 1

    if changed:
        save_history(history)

    return ThumbnailRegenerateResult(
        generated_count=generated_count,
        missing_snapshot_count=missing_snapshot_count,
    )


def hide_snapshot_object(obj: bpy.types.Object) -> None:
    obj.hide_viewport = True
    obj.hide_render = True
    obj.hide_select = True
    try:
        if obj.name in bpy.context.view_layer.objects:
            obj.hide_set(True)
    except RuntimeError:
        pass


def show_fork_object(obj: bpy.types.Object) -> None:
    obj.hide_viewport = False
    obj.hide_render = False
    obj.hide_select = False
    try:
        if obj.name in bpy.context.view_layer.objects:
            obj.hide_set(False)
    except RuntimeError:
        pass


def unique_fork_name(base_name: str, existing_names) -> str:
    clean_base = base_name.strip() or "Object"
    for index in range(1, 10000):
        name = f"{clean_base}_branch{index:02d}"
        if name not in existing_names:
            return name
    return f"{clean_base}_branch{new_id()[:8]}"


def unique_name(base_name: str, existing_names) -> str:
    clean_base = base_name.strip() or "Data"
    if clean_base not in existing_names:
        return clean_base

    for index in range(1, 10000):
        name = f"{clean_base}_{index:02d}"
        if name not in existing_names:
            return name
    return f"{clean_base}_{new_id()[:8]}"


def capture_object_state(source: bpy.types.Object) -> dict[str, object]:
    visibility = {
        "hide_viewport": bool(source.hide_viewport),
        "hide_render": bool(source.hide_render),
    }
    if hasattr(source, "hide_select"):
        visibility["hide_select"] = bool(source.hide_select)
    try:
        visibility["hide_get"] = bool(source.hide_get())
    except RuntimeError:
        visibility["hide_get"] = False

    return {
        "visibility": visibility,
        "collection_names": [collection.name for collection in source.users_collection],
        "modifier_references": capture_rna_collection_references(source.modifiers, source),
        "constraint_references": capture_rna_collection_references(source.constraints, source),
        "animation_references": capture_animation_references(source),
    }


def capture_id_reference(
    value: bpy.types.ID, owner: bpy.types.ID | None = None
) -> dict[str, object]:
    return {
        "id_type": value.bl_rna.identifier,
        "name": value.name,
        "is_self": value == owner,
    }


def capture_rna_collection_references(
    collection,
    owner: bpy.types.ID | None = None,
) -> list[dict[str, object]]:
    references = []
    for item in collection:
        item_references = []
        for prop in item.bl_rna.properties:
            if prop.identifier in RNA_COPY_EXCLUDED_PROPS or prop.type != "POINTER":
                continue
            try:
                value = getattr(item, prop.identifier)
            except (AttributeError, TypeError, ValueError, RuntimeError):
                continue
            if not isinstance(value, bpy.types.ID):
                continue
            reference = capture_id_reference(value, owner)
            reference["property"] = prop.identifier
            item_references.append(reference)

        references.append(
            {
                "name": item.name,
                "type": getattr(item, "type", ""),
                "references": item_references,
            }
        )
    return references


def capture_animation_references(source: bpy.types.Object) -> list[dict[str, object]]:
    animation_data = source.animation_data
    if animation_data is None:
        return []

    references = []
    for fcurve in animation_data.drivers:
        fcurve_references = []
        driver = fcurve.driver
        for variable_index, variable in enumerate(driver.variables):
            for target_index, target in enumerate(variable.targets):
                if target.id is None:
                    continue
                reference = capture_id_reference(target.id, source)
                reference.update(
                    {
                        "variable_name": variable.name,
                        "variable_index": variable_index,
                        "target_index": target_index,
                    }
                )
                fcurve_references.append(reference)

        references.append(
            {
                "data_path": fcurve.data_path,
                "array_index": fcurve.array_index,
                "references": fcurve_references,
            }
        )
    return references


def make_snapshot_action_copy(action: bpy.types.Action | None, commit_id: str):
    if action is None:
        return None
    action_copy = action.copy()
    action_copy.name = f".nyanneco_action_{action.name}_{commit_id[:8]}"
    return action_copy


def action_display_name(action: bpy.types.Action) -> str:
    prefix = ".nyanneco_action_"
    name = action.name
    if not name.startswith(prefix):
        return name

    display_name, separator, suffix = name[len(prefix) :].rpartition("_")
    if (
        separator
        and len(suffix) == 8
        and all(character in "0123456789abcdef" for character in suffix.lower())
    ):
        return display_name
    return name[len(prefix) :]


def make_restore_action_copy(
    action: bpy.types.Action | None,
    preferred_name: str | None = None,
):
    if action is None:
        return None
    action_copy = action.copy()
    action_copy.name = preferred_name or action_display_name(action)
    return action_copy


def capture_animation_actions(animation_data) -> list[bpy.types.Action]:
    if animation_data is None:
        return []

    actions = []
    seen_action_names = set()
    if animation_data.action is not None:
        seen_action_names.add(animation_data.action.name)
        actions.append(animation_data.action)
    for track in animation_data.nla_tracks:
        for strip in track.strips:
            if strip.action is None or strip.action.name in seen_action_names:
                continue
            seen_action_names.add(strip.action.name)
            actions.append(strip.action)
    return actions


def remove_action_if_unused(action: bpy.types.Action | None) -> None:
    try:
        if action is None or action.users > 0 or action.use_fake_user:
            return
        bpy.data.actions.remove(action)
    except ReferenceError:
        return


def freeze_snapshot_animation_data(snapshot: bpy.types.Object, commit_id: str) -> None:
    animation_data = snapshot.animation_data
    if animation_data is None:
        return

    if animation_data.action is not None:
        animation_data.action = make_snapshot_action_copy(animation_data.action, commit_id)

    for track in animation_data.nla_tracks:
        for strip in track.strips:
            if strip.action is not None:
                strip.action = make_snapshot_action_copy(strip.action, commit_id)


def create_snapshot_object(
    source: bpy.types.Object,
    commit_id: str,
) -> bpy.types.Object:
    snapshot = source.copy()
    if source.data is not None:
        snapshot.data = source.data.copy()
    snapshot.name = f".nyanneco_snapshot_{source.name}_{commit_id[:8]}"
    if snapshot.data is not None:
        snapshot.data.name = f"{snapshot.name}_data"
    snapshot[SNAPSHOT_MARKER_PROP] = True
    snapshot[SNAPSHOT_COMMIT_ID_PROP] = commit_id
    snapshot[OBJECT_UUID_PROP] = source[OBJECT_UUID_PROP]
    freeze_snapshot_animation_data(snapshot, commit_id)

    collection = get_snapshot_collection()
    collection.objects.link(snapshot)
    hide_snapshot_object(snapshot)
    enforce_snapshot_collection_lock(create=False)
    return snapshot


def copy_snapshot_object(
    source_commit: CommitRecord,
    target_object_uuid: str,
    commit_id: str,
) -> bpy.types.Object:
    source_snapshot = bpy.data.objects.get(source_commit.snapshot_object_name)
    if source_snapshot is None:
        msg = f"Snapshot object not found: {source_commit.snapshot_object_name}"
        raise ValueError(msg)

    snapshot = source_snapshot.copy()
    if source_snapshot.data is not None:
        snapshot.data = source_snapshot.data.copy()

    snapshot.name = unique_name(
        f".nyanneco_snapshot_{source_commit.source_object_name}_{commit_id[:8]}",
        bpy.data.objects,
    )
    if snapshot.data is not None:
        data_collection_name = {
            "MESH": "meshes",
            "CURVE": "curves",
        }.get(source_commit.object_type)
        data_collection = getattr(bpy.data, data_collection_name, None)
        existing_data_names = data_collection if data_collection is not None else ()
        snapshot.data.name = unique_name(f"{snapshot.name}_data", existing_data_names)

    snapshot[SNAPSHOT_MARKER_PROP] = True
    snapshot[SNAPSHOT_COMMIT_ID_PROP] = commit_id
    snapshot[OBJECT_UUID_PROP] = target_object_uuid
    freeze_snapshot_animation_data(snapshot, commit_id)

    collection = get_snapshot_collection()
    collection.objects.link(snapshot)
    hide_snapshot_object(snapshot)
    enforce_snapshot_collection_lock(create=False)
    return snapshot


def copy_or_render_thumbnail(
    source_commit: CommitRecord,
    snapshot: bpy.types.Object,
    commit_id: str,
) -> str | None:
    if source_commit.thumbnail_path:
        source_path = Path(bpy.path.abspath(source_commit.thumbnail_path))
        if source_path.exists():
            target_path = get_thumbnail_path(commit_id)
            shutil.copy2(source_path, target_path)
            return str(target_path)

    return render_thumbnail(snapshot, commit_id)


def remove_snapshot_from_visible_collections(snapshot: bpy.types.Object) -> None:
    snapshot_collection = get_snapshot_collection()
    for collection in list(snapshot.users_collection):
        if collection != snapshot_collection:
            collection.objects.unlink(snapshot)


def create_commit_record(
    source: bpy.types.Object,
    message: str = "",
    branch_source_object_uuid: str | None = None,
    branch_source_commit_id: str | None = None,
    render_preview: bool = True,
) -> CommitRecord:
    object_uuid = get_object_uuid(source)
    commit_id = new_id()
    snapshot = create_snapshot_object(source, commit_id)
    remove_snapshot_from_visible_collections(snapshot)
    thumbnail_path = render_thumbnail(snapshot, commit_id) if render_preview else None
    return CommitRecord(
        commit_id=commit_id,
        object_uuid=object_uuid,
        source_object_name=source.name,
        snapshot_object_name=snapshot.name,
        snapshot_data_name=snapshot.data.name if snapshot.data else None,
        object_type=source.type,
        created_at=local_timestamp(),
        message=message.strip(),
        thumbnail_path=thumbnail_path,
        material_names=capture_material_names(source),
        object_state=capture_object_state(source),
        branch_source_object_uuid=branch_source_object_uuid,
        branch_source_commit_id=branch_source_commit_id,
    )


def store_commit(
    source: bpy.types.Object,
    message: str = "",
    branch_source_object_uuid: str | None = None,
    branch_source_commit_id: str | None = None,
    activate: bool = True,
) -> CommitRecord:
    history = load_history()
    existing_object_uuid = source.get(OBJECT_UUID_PROP)
    issue = commit_limit_issue(
        history,
        str(existing_object_uuid) if existing_object_uuid else None,
    )
    if issue is not None:
        raise ValueError(iface_format(issue.message, **issue.kwargs))

    object_uuid = get_object_uuid(source)
    object_history = history.objects.get(object_uuid)
    active_commit_id = object_history.active_commit_id if object_history is not None else None
    commit = create_commit_record(
        source,
        message,
        branch_source_object_uuid=branch_source_object_uuid,
        branch_source_commit_id=branch_source_commit_id,
    )
    history.add_commit(commit)
    if object_history is not None and active_commit_id is not None:
        draft_commit = object_history.draft_commits.pop(active_commit_id, None)
        if draft_commit is not None:
            remove_snapshot_resources(draft_commit)
    if not activate:
        object_history = history.objects.get(commit.object_uuid)
        if object_history is not None:
            object_history.active_commit_id = None
    save_history(history)
    return commit


def rounded_float(value: float) -> float:
    return round(float(value), 6)


def vector_signature(values) -> tuple[float, ...]:
    return tuple(rounded_float(value) for value in values)


def object_transform_signature(obj: bpy.types.Object) -> tuple[tuple[float, ...], ...]:
    return (
        vector_signature(obj.location),
        vector_signature(obj.rotation_euler),
        vector_signature(obj.scale),
        vector_signature(obj.delta_location),
        vector_signature(obj.delta_rotation_euler),
        vector_signature(obj.delta_scale),
    )


def mesh_data_signature(data: bpy.types.Mesh) -> tuple:
    return (
        tuple(vector_signature(vertex.co) for vertex in data.vertices),
        tuple(tuple(poly.vertices) for poly in data.polygons),
        tuple(poly.material_index for poly in data.polygons),
    )


def curve_point_signature(point) -> tuple:
    co = getattr(point, "co", None)
    if co is not None:
        return vector_signature(co)
    return (
        *vector_signature(point.co),
        rounded_float(getattr(point, "radius", 1.0)),
        rounded_float(getattr(point, "tilt", 0.0)),
    )


def curve_data_signature(data: bpy.types.Curve) -> tuple:
    return tuple(
        (
            spline.type,
            spline.material_index,
            tuple(curve_point_signature(point) for point in spline.points),
            tuple(curve_point_signature(point) for point in spline.bezier_points),
        )
        for spline in data.splines
    )


def id_property_signature(item, protected_properties: set[str] | None = None) -> tuple:
    protected = protected_properties or set()
    try:
        keys = sorted(key for key in item.keys() if key not in protected)
    except TypeError:
        return ()
    return tuple((key, value_signature(item[key])) for key in keys)


def value_signature(value):
    if isinstance(value, bpy.types.ID):
        return (value.bl_rna.identifier, value.name)
    if isinstance(value, float):
        return rounded_float(value)
    if isinstance(value, int | bool | str | type(None)):
        return value
    if isinstance(value, Vector):
        return vector_signature(value)
    if hasattr(value, "to_tuple"):
        try:
            return tuple(value_signature(item) for item in value.to_tuple())
        except (AttributeError, TypeError, ValueError, RuntimeError):
            pass
    if isinstance(value, list | tuple):
        return tuple(value_signature(item) for item in value)
    try:
        return tuple(value_signature(item) for item in value)
    except (TypeError, ValueError, RuntimeError):
        return repr(value)


def rna_signature(
    item,
    excluded_properties: set[str] | None = None,
) -> tuple:
    excluded = RNA_COPY_EXCLUDED_PROPS | (excluded_properties or set())
    values = []
    for prop in item.bl_rna.properties:
        identifier = prop.identifier
        if identifier in excluded:
            continue
        try:
            value = getattr(item, identifier)
        except (AttributeError, TypeError, ValueError, RuntimeError):
            continue
        values.append((identifier, value_signature(value)))
    return tuple(values)


def rna_collection_signature(collection) -> tuple:
    return tuple(
        (
            item.name,
            getattr(item, "type", ""),
            rna_signature(item, excluded_properties={"name", "type"}),
            id_property_signature(item),
        )
        for item in collection
    )


def vertex_group_signature(obj: bpy.types.Object) -> tuple:
    if not hasattr(obj, "vertex_groups"):
        return ()
    return tuple((group.name, bool(group.lock_weight)) for group in obj.vertex_groups)


def action_fcurve_signature(action: bpy.types.Action | None) -> tuple | None:
    if action is None:
        return None

    if not hasattr(action, "fcurves") and hasattr(action, "layers"):
        return tuple(
            (
                fcurve.data_path,
                fcurve.array_index,
                tuple(
                    (
                        rounded_float(point.co.x),
                        rounded_float(point.co.y),
                        point.interpolation,
                        point.easing,
                    )
                    for point in fcurve.keyframe_points
                ),
            )
            for layer in action.layers
            for strip in getattr(layer, "strips", ())
            for channelbag in getattr(strip, "channelbags", ())
            for fcurve in getattr(channelbag, "fcurves", ())
        )

    return tuple(
        (
            fcurve.data_path,
            fcurve.array_index,
            tuple(
                (
                    rounded_float(point.co.x),
                    rounded_float(point.co.y),
                    point.interpolation,
                    point.easing,
                )
                for point in fcurve.keyframe_points
            ),
        )
        for fcurve in action.fcurves
    )


def nla_signature(animation_data) -> tuple:
    if animation_data is None:
        return ()
    return tuple(
        (
            track.name,
            bool(track.mute),
            bool(track.is_solo),
            tuple(
                (
                    strip.name,
                    rounded_float(strip.frame_start),
                    rounded_float(strip.frame_end),
                    rounded_float(strip.action_frame_start),
                    rounded_float(strip.action_frame_end),
                    action_fcurve_signature(strip.action),
                )
                for strip in track.strips
            ),
        )
        for track in animation_data.nla_tracks
    )


def driver_signature(animation_data) -> tuple:
    if animation_data is None:
        return ()
    return tuple(
        (
            fcurve.data_path,
            fcurve.array_index,
            fcurve.driver.type,
            fcurve.driver.expression,
            tuple(
                (
                    variable.name,
                    variable.type,
                    tuple(
                        (
                            target.id.bl_rna.identifier if target.id is not None else None,
                            target.id.name if target.id is not None else None,
                            target.data_path,
                            target.bone_target,
                            target.transform_type,
                            target.transform_space,
                        )
                        for target in variable.targets
                    ),
                )
                for variable in fcurve.driver.variables
            ),
        )
        for fcurve in animation_data.drivers
    )


def animation_signature(obj: bpy.types.Object) -> tuple | None:
    animation_data = obj.animation_data
    if animation_data is None:
        return None
    return (
        action_fcurve_signature(animation_data.action),
        nla_signature(animation_data),
        driver_signature(animation_data),
    )


def object_display_signature(
    obj: bpy.types.Object,
    visibility_override: dict[str, object] | None = None,
) -> tuple:
    if visibility_override is None:
        try:
            hide_get = bool(obj.hide_get())
        except RuntimeError:
            hide_get = False
        visibility = (
            bool(obj.hide_viewport),
            bool(obj.hide_render),
            bool(getattr(obj, "hide_select", False)),
            hide_get,
        )
    else:
        visibility = (
            bool(visibility_override.get("hide_viewport", False)),
            bool(visibility_override.get("hide_render", False)),
            bool(visibility_override.get("hide_select", False)),
            bool(visibility_override.get("hide_get", False)),
        )
    return (
        *visibility,
        obj.display_type,
        obj.display_bounds_type,
        bool(obj.show_name),
        bool(obj.show_axis),
        bool(obj.show_texture_space),
        bool(obj.show_wire),
        bool(obj.show_in_front),
        value_signature(obj.color),
        obj.pass_index,
    )


def object_draft_signature(
    obj: bpy.types.Object,
    visibility_override: dict[str, object] | None = None,
) -> tuple:
    data_signature = None
    if obj.type == "MESH" and obj.data is not None:
        data_signature = mesh_data_signature(obj.data)
    elif obj.type == "CURVE" and obj.data is not None:
        data_signature = curve_data_signature(obj.data)

    return (
        obj.type,
        object_transform_signature(obj),
        capture_material_names(obj),
        vertex_group_signature(obj),
        rna_collection_signature(obj.modifiers),
        rna_collection_signature(obj.constraints),
        id_property_signature(obj, SNAPSHOT_INTERNAL_PROPS),
        animation_signature(obj),
        object_display_signature(obj, visibility_override),
        data_signature,
    )


def commit_visibility(commit: CommitRecord) -> dict[str, object] | None:
    object_state = commit.object_state or {}
    visibility = object_state.get("visibility") if isinstance(object_state, dict) else None
    return visibility if isinstance(visibility, dict) else None


def object_differs_from_commit(source: bpy.types.Object, commit: CommitRecord) -> bool:
    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    if snapshot is None:
        return True
    try:
        return object_draft_signature(source) != object_draft_signature(
            snapshot,
            visibility_override=commit_visibility(commit),
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return True


def store_commit_draft(source: bpy.types.Object, base_commit_id: str) -> CommitRecord:
    history = load_history()
    object_uuid = get_object_uuid(source)
    object_history = history.ensure_object(object_uuid, source.name)

    if object_history.draft_commits.get(base_commit_id) is not None:
        remove_snapshot_resources(object_history.draft_commits[base_commit_id])

    draft_commit = create_commit_record(
        source,
        message="",
        render_preview=True,
    )
    object_history.draft_commits[base_commit_id] = draft_commit
    save_history(history)
    return draft_commit


def get_commit_draft(object_uuid: str, base_commit_id: str) -> CommitRecord | None:
    object_history = load_history().objects.get(object_uuid)
    if object_history is None:
        return None
    return object_history.draft_commits.get(base_commit_id)


def delete_commit_draft(object_uuid: str, base_commit_id: str) -> CommitRecord | None:
    history = load_history()
    object_history = history.objects.get(object_uuid)
    if object_history is None:
        return None

    draft_commit = object_history.draft_commits.pop(base_commit_id, None)
    if draft_commit is None:
        return None

    remove_snapshot_resources(draft_commit)
    save_history(history)
    return draft_commit


def target_collection_for_fork(
    source: bpy.types.Object,
    fallback_collection: bpy.types.Collection | None,
) -> bpy.types.Collection:
    for collection in source.users_collection:
        if collection.name != SNAPSHOT_COLLECTION_NAME:
            return collection

    if fallback_collection is not None and fallback_collection.name != SNAPSHOT_COLLECTION_NAME:
        return fallback_collection

    return bpy.context.scene.collection


def clear_snapshot_properties(obj: bpy.types.Object) -> None:
    for prop_name in (SNAPSHOT_MARKER_PROP, SNAPSHOT_COMMIT_ID_PROP, OBJECT_UUID_PROP):
        if prop_name in obj:
            del obj[prop_name]


def create_fork_object(
    source: bpy.types.Object,
    commit: CommitRecord,
    fallback_collection: bpy.types.Collection | None = None,
) -> tuple[bpy.types.Object, list[str]]:
    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    if snapshot is None:
        msg = f"Snapshot object not found: {commit.snapshot_object_name}"
        raise ValueError(msg)

    fork = snapshot.copy()
    if snapshot.data is not None:
        fork.data = snapshot.data.copy()

    fork.name = unique_fork_name(commit.source_object_name, bpy.data.objects)
    if fork.data is not None:
        data_collection_name = {
            "MESH": "meshes",
            "CURVE": "curves",
        }.get(commit.object_type)
        data_collection = getattr(bpy.data, data_collection_name, None)
        existing_data_names = data_collection if data_collection is not None else ()
        fork.data.name = unique_name(f"{fork.name}_data", existing_data_names)

    clear_snapshot_properties(fork)
    assign_new_object_uuid(fork)

    target_collection = target_collection_for_fork(source, fallback_collection)
    target_collection.objects.link(fork)
    show_fork_object(fork)
    missing_material_names = restore_material_slots(fork, commit)

    return fork, missing_material_names


def copy_commit_for_fork(
    source_commit: CommitRecord,
    target_object_uuid: str,
    target_object_name: str,
) -> CommitRecord:
    commit_id = new_id()
    snapshot = copy_snapshot_object(source_commit, target_object_uuid, commit_id)
    thumbnail_path = copy_or_render_thumbnail(source_commit, snapshot, commit_id)
    return CommitRecord(
        commit_id=commit_id,
        object_uuid=target_object_uuid,
        source_object_name=target_object_name,
        snapshot_object_name=snapshot.name,
        snapshot_data_name=snapshot.data.name if snapshot.data else None,
        object_type=source_commit.object_type,
        created_at=source_commit.created_at,
        message=source_commit.message,
        thumbnail_path=thumbnail_path,
        material_names=copy.deepcopy(source_commit.material_names),
        object_state=copy.deepcopy(source_commit.object_state),
        branch_source_object_uuid=source_commit.object_uuid,
        branch_source_commit_id=source_commit.commit_id,
    )


def copy_commit_for_merge(
    source_commit: CommitRecord,
    target_object_uuid: str,
    target_object_name: str,
) -> CommitRecord:
    commit_id = new_id()
    snapshot = copy_snapshot_object(source_commit, target_object_uuid, commit_id)
    thumbnail_path = copy_or_render_thumbnail(source_commit, snapshot, commit_id)
    return CommitRecord(
        commit_id=commit_id,
        object_uuid=target_object_uuid,
        source_object_name=target_object_name,
        snapshot_object_name=snapshot.name,
        snapshot_data_name=snapshot.data.name if snapshot.data else None,
        object_type=source_commit.object_type,
        created_at=source_commit.created_at,
        message=source_commit.message,
        thumbnail_path=thumbnail_path,
        material_names=copy.deepcopy(source_commit.material_names),
        object_state=copy.deepcopy(source_commit.object_state),
        branch_source_object_uuid=source_commit.branch_source_object_uuid,
        branch_source_commit_id=source_commit.branch_source_commit_id,
    )


def copy_history_for_fork(
    history: HistoryDocument,
    source_history: ObjectHistory,
    selected_commit_id: str,
    target_object_uuid: str,
    target_object_name: str,
) -> CommitRecord:
    fork_history = ObjectHistory(
        object_uuid=target_object_uuid,
        display_name=target_object_name,
        branch_source_object_uuid=source_history.object_uuid,
        branch_source_commit_id=selected_commit_id,
    )
    selected_copy: CommitRecord | None = None

    for source_commit in source_history.commits:
        copied_commit = copy_commit_for_fork(
            source_commit,
            target_object_uuid,
            target_object_name,
        )
        fork_history.commits.append(copied_commit)
        if source_commit.commit_id in source_history.archived_commit_ids:
            fork_history.archived_commit_ids.append(copied_commit.commit_id)
        if source_commit.commit_id == selected_commit_id:
            selected_copy = copied_commit

    if selected_copy is None:
        msg = f"Snapshot history entry was not found: {selected_commit_id}"
        raise ValueError(msg)

    fork_history.commits.sort(key=lambda item: item.created_at)
    fork_history.active_commit_id = selected_copy.commit_id
    history.objects[target_object_uuid] = fork_history
    return selected_copy


def find_object_by_uuid(
    object_uuid: str,
    exclude: bpy.types.Object | None = None,
) -> bpy.types.Object | None:
    for obj in bpy.data.objects:
        if obj == exclude or obj.type not in SUPPORTED_OBJECT_TYPES or is_snapshot_object(obj):
            continue
        if str(obj.get(OBJECT_UUID_PROP, "")) == object_uuid:
            return obj
    return None


def equivalent_target_commit_id(
    target_history: ObjectHistory,
    source_commit: CommitRecord,
) -> str | None:
    origin_object_uuid = source_commit.branch_source_object_uuid
    origin_commit_id = source_commit.branch_source_commit_id
    if origin_object_uuid != target_history.object_uuid or not origin_commit_id:
        return None

    if target_history.get_commit(origin_commit_id) is not None:
        return origin_commit_id

    for target_commit in target_history.commits:
        if (
            target_commit.branch_source_object_uuid == origin_object_uuid
            and target_commit.branch_source_commit_id == origin_commit_id
        ):
            return target_commit.commit_id
    return None


def merge_fork_history(fork: bpy.types.Object) -> ForkMergeResult:
    fork_uuid = str(fork.get(OBJECT_UUID_PROP, ""))
    if not fork_uuid:
        msg = "The selected object has no snapshot history."
        raise ValueError(msg)

    history = load_history()
    fork_history = history.objects.get(fork_uuid)
    if fork_history is None or not fork_history.branch_source_object_uuid:
        msg = "The selected object is not a branched snapshot object."
        raise ValueError(msg)

    target_object_uuid = fork_history.branch_source_object_uuid
    target_obj = find_object_by_uuid(target_object_uuid, exclude=fork)
    if target_obj is None:
        msg = "Branch source object was not found."
        raise ValueError(msg)

    target_history = history.objects.get(target_object_uuid)
    if target_history is None:
        msg = "Branch source history was not found."
        raise ValueError(msg)

    merged_count = 0
    reused_count = 0
    for fork_commit in fork_history.commits:
        if equivalent_target_commit_id(target_history, fork_commit) is not None:
            reused_count += 1
            continue

        merged_commit = copy_commit_for_merge(
            fork_commit,
            target_object_uuid,
            target_obj.name,
        )
        target_history.commits.append(merged_commit)
        if fork_commit.commit_id in fork_history.archived_commit_ids:
            target_history.archived_commit_ids.append(merged_commit.commit_id)
        merged_count += 1

    target_history.commits.sort(key=lambda item: item.created_at)
    target_history.archived_commit_ids = sorted(set(target_history.archived_commit_ids))

    removed_commits = fork_history.clear_commits()
    for removed_commit in removed_commits:
        remove_snapshot_resources(removed_commit)
    del history.objects[fork_uuid]

    for obj in list(bpy.context.selected_objects):
        obj.select_set(False)
    bpy.context.view_layer.objects.active = target_obj
    target_obj.select_set(True)
    remove_object_if_unused(fork)

    save_history(history)
    return ForkMergeResult(
        target_object=target_obj,
        merged_commit_count=merged_count,
        reused_commit_count=reused_count,
        removed_branch_commit_count=len(removed_commits),
    )


def fork_commit(
    source: bpy.types.Object,
    commit: CommitRecord,
    fallback_collection: bpy.types.Collection | None = None,
    message: str = "",
) -> ForkResult:
    fork, missing_material_names = create_fork_object(source, commit, fallback_collection)
    history = load_history()
    source_history = history.objects.get(commit.object_uuid)
    if source_history is None:
        msg = f"Snapshot history was not found: {commit.object_uuid}"
        raise ValueError(msg)

    fork_uuid = str(fork[OBJECT_UUID_PROP])
    initial_commit = copy_history_for_fork(
        history,
        source_history,
        commit.commit_id,
        fork_uuid,
        fork.name,
    )
    save_history(history)

    for obj in list(bpy.context.selected_objects):
        obj.select_set(False)
    bpy.context.view_layer.objects.active = fork
    fork.select_set(True)

    return ForkResult(
        obj=fork,
        commit=initial_commit,
        missing_material_names=missing_material_names,
    )


def remove_snapshot_resources(commit: CommitRecord) -> None:
    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    snapshot_data = snapshot.data if snapshot is not None else None
    snapshot_actions = (
        capture_animation_actions(snapshot.animation_data) if snapshot is not None else []
    )

    if snapshot is not None:
        bpy.data.objects.remove(snapshot, do_unlink=True)

    for action in snapshot_actions:
        remove_action_if_unused(action)

    if snapshot_data is not None and snapshot_data.users == 0:
        data_collection_name = {
            "MESH": "meshes",
            "CURVE": "curves",
        }.get(commit.object_type)
        data_collection = getattr(bpy.data, data_collection_name, None)
        if data_collection is not None and snapshot_data.name in data_collection:
            data_collection.remove(snapshot_data)

    if commit.thumbnail_path:
        thumbnail_path = Path(bpy.path.abspath(commit.thumbnail_path))
        if thumbnail_path.exists():
            thumbnail_path.unlink()


def commit_records_have_same_snapshot_state(
    first: CommitRecord,
    second: CommitRecord,
) -> bool:
    first_snapshot = bpy.data.objects.get(first.snapshot_object_name)
    second_snapshot = bpy.data.objects.get(second.snapshot_object_name)
    if first_snapshot is None or second_snapshot is None:
        return False

    try:
        return object_draft_signature(
            first_snapshot,
            visibility_override=commit_visibility(first),
        ) == object_draft_signature(
            second_snapshot,
            visibility_override=commit_visibility(second),
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return False


def cleanup_redundant_commit_drafts(object_uuid: str | None = None) -> int:
    history = load_history()
    if object_uuid is None:
        object_histories = list(history.objects.values())
    else:
        object_history = history.objects.get(str(object_uuid))
        object_histories = [] if object_history is None else [object_history]

    removed_count = 0
    for object_history in object_histories:
        for base_commit_id, draft_commit in list(object_history.draft_commits.items()):
            base_commit = object_history.get_commit(base_commit_id)
            if base_commit is not None and not commit_records_have_same_snapshot_state(
                base_commit,
                draft_commit,
            ):
                continue

            object_history.draft_commits.pop(base_commit_id, None)
            remove_snapshot_resources(draft_commit)
            removed_count += 1

    if removed_count:
        save_history(history)
    return removed_count


def preferred_object_for_uuid(
    object_uuid: str,
    objects: list[bpy.types.Object],
    history: HistoryDocument,
) -> bpy.types.Object:
    object_history = history.objects.get(object_uuid)
    if object_history is not None:
        preferred_names = [object_history.display_name]
        preferred_names.extend(
            commit.source_object_name for commit in reversed(object_history.commits)
        )
        for preferred_name in preferred_names:
            for obj in objects:
                if obj.name == preferred_name:
                    return obj

    return objects[0]


def remove_object_if_unused(obj: bpy.types.Object) -> None:
    data = obj.data
    bpy.data.objects.remove(obj, do_unlink=True)
    remove_data_block_if_unused(data)


def remove_empty_duplicate_snapshot_collections() -> None:
    if not hasattr(bpy.data, "collections"):
        return

    for collection in list(bpy.data.collections):
        if collection.name == SNAPSHOT_COLLECTION_NAME:
            continue
        if not collection.name.startswith(f"{SNAPSHOT_COLLECTION_NAME}."):
            continue
        if collection.objects:
            continue
        bpy.data.collections.remove(collection)


def cleanup_copied_snapshot_objects(history: HistoryDocument) -> list[str]:
    referenced_by_commit_id = {
        commit.commit_id: commit.snapshot_object_name
        for object_history in history.objects.values()
        for commit in object_history.commits
    }
    for object_history in history.objects.values():
        for draft_commit in object_history.draft_commits.values():
            referenced_by_commit_id[draft_commit.commit_id] = draft_commit.snapshot_object_name
    removed_names = []

    for obj in list(bpy.data.objects):
        if not is_snapshot_object(obj):
            continue

        commit_id = obj.get(SNAPSHOT_COMMIT_ID_PROP)
        if not commit_id:
            continue

        referenced_name = referenced_by_commit_id.get(str(commit_id))
        if referenced_name is None or obj.name == referenced_name:
            continue

        removed_names.append(obj.name)
        remove_object_if_unused(obj)

    remove_empty_duplicate_snapshot_collections()
    return removed_names


def repair_duplicate_object_uuids() -> UUIDRepairResult:
    if not hasattr(bpy.data, "objects"):
        return UUIDRepairResult(reassigned_object_names=[], removed_snapshot_names=[])

    object_groups: dict[str, list[bpy.types.Object]] = {}
    has_snapshot_objects = False
    for obj in bpy.data.objects:
        if is_snapshot_object(obj):
            has_snapshot_objects = True
            continue
        if obj.type not in SUPPORTED_OBJECT_TYPES:
            continue

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            continue

        object_groups.setdefault(str(object_uuid), []).append(obj)

    duplicated_groups = {
        object_uuid: objects for object_uuid, objects in object_groups.items() if len(objects) > 1
    }
    if not duplicated_groups and not has_snapshot_objects:
        return UUIDRepairResult(reassigned_object_names=[], removed_snapshot_names=[])

    history = load_history()
    reassigned_names = []
    for object_uuid, objects in duplicated_groups.items():
        keep = preferred_object_for_uuid(object_uuid, objects, history)
        for obj in objects:
            if obj == keep:
                continue
            assign_new_object_uuid(obj)
            reassigned_names.append(obj.name)

    removed_snapshot_names = cleanup_copied_snapshot_objects(history)
    return UUIDRepairResult(
        reassigned_object_names=reassigned_names,
        removed_snapshot_names=removed_snapshot_names,
    )


def has_duplicate_object_uuid(obj: bpy.types.Object) -> bool:
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES or is_snapshot_object(obj):
        return False

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return False

    matching_objects = [
        candidate
        for candidate in bpy.data.objects
        if candidate.type in SUPPORTED_OBJECT_TYPES
        and not is_snapshot_object(candidate)
        and str(candidate.get(OBJECT_UUID_PROP, "")) == str(object_uuid)
    ]
    return len(matching_objects) > 1


def delete_commit(object_uuid: str, commit_id: str) -> CommitRecord | None:
    history = load_history()
    object_history = history.objects.get(object_uuid)
    draft_commit = (
        object_history.draft_commits.pop(commit_id, None) if object_history is not None else None
    )
    removed = history.remove_commit(object_uuid, commit_id)
    if removed is None:
        if draft_commit is not None:
            object_history.draft_commits[commit_id] = draft_commit
        return None

    if draft_commit is not None:
        remove_snapshot_resources(draft_commit)
    remove_snapshot_resources(removed)
    save_history(history)
    return removed


def archive_commit(object_uuid: str, commit_id: str) -> bool:
    history = load_history()
    object_history = history.objects.get(object_uuid)
    if object_history is None or object_history.get_commit(commit_id) is None:
        return False

    if commit_id not in object_history.archived_commit_ids:
        object_history.archived_commit_ids.append(commit_id)
        save_history(history)
    return True


def unarchive_commit(object_uuid: str, commit_id: str) -> bool:
    history = load_history()
    object_history = history.objects.get(object_uuid)
    if object_history is None or object_history.get_commit(commit_id) is None:
        return False

    if commit_id in object_history.archived_commit_ids:
        object_history.archived_commit_ids.remove(commit_id)
        save_history(history)
    return True


def update_commit_message(
    object_uuid: str,
    commit_id: str,
    message: str,
) -> CommitRecord | None:
    history = load_history()
    commit = history.get_commit(object_uuid, commit_id)
    if commit is None:
        return None

    commit.message = message.strip()
    save_history(history)
    return commit


def delete_all_commits(object_uuid: str) -> list[CommitRecord]:
    history = load_history()
    removed_commits = history.clear_object_commits(object_uuid)
    for commit in removed_commits:
        remove_snapshot_resources(commit)
    save_history(history)
    return removed_commits


def all_commits(history: HistoryDocument) -> list[CommitRecord]:
    return [
        commit for object_history in history.objects.values() for commit in object_history.commits
    ]


def all_snapshot_records(history: HistoryDocument) -> list[CommitRecord]:
    records = all_commits(history)
    records.extend(
        draft_commit
        for object_history in history.objects.values()
        for draft_commit in object_history.draft_commits.values()
    )
    return records


def repository_integrity_status(*, readonly: bool = True) -> RepositoryIntegrityStatus:
    has_history_text = bpy.data.texts.get(HISTORY_TEXT_NAME) is not None
    if not has_history_text:
        return RepositoryIntegrityStatus(
            has_history_text=False,
            snapshot_record_count=0,
            collection_missing=False,
            missing_snapshot_object_names=[],
            unlinked_snapshot_object_names=[],
        )

    history = load_history_readonly() if readonly else load_history()
    snapshot_records = all_snapshot_records(history)
    collection = bpy.data.collections.get(SNAPSHOT_COLLECTION_NAME)
    missing_snapshot_object_names = []
    unlinked_snapshot_object_names = []
    for commit in snapshot_records:
        snapshot = bpy.data.objects.get(commit.snapshot_object_name)
        if snapshot is None:
            missing_snapshot_object_names.append(commit.snapshot_object_name)
            continue
        if collection is not None and snapshot.name not in collection.objects:
            unlinked_snapshot_object_names.append(snapshot.name)

    return RepositoryIntegrityStatus(
        has_history_text=True,
        snapshot_record_count=len(snapshot_records),
        collection_missing=collection is None,
        missing_snapshot_object_names=missing_snapshot_object_names,
        unlinked_snapshot_object_names=unlinked_snapshot_object_names,
    )


def repository_integrity_warnings(*, readonly: bool = True) -> list[str]:
    status = repository_integrity_status(readonly=readonly)
    if not status.is_damaged:
        return []

    warnings = []
    if status.collection_missing:
        warnings.append("Snapshot repository collection is missing.")

    missing_snapshot_count = len(status.missing_snapshot_object_names)
    if missing_snapshot_count:
        warnings.append(
            iface_format(
                "Snapshot repository is missing {count} snapshot objects.",
                count=missing_snapshot_count,
            )
        )
    unlinked_snapshot_count = len(status.unlinked_snapshot_object_names)
    if unlinked_snapshot_count:
        warnings.append(
            iface_format(
                "Snapshot repository has {count} exposed snapshot objects.",
                count=unlinked_snapshot_count,
            )
        )
    return warnings


def repair_repository_collection() -> RepositoryRepairResult:
    status = repository_integrity_status(readonly=False)
    if not status.can_repair:
        return RepositoryRepairResult(
            repaired_collection=False,
            relinked_snapshot_count=0,
            missing_snapshot_object_names=status.missing_snapshot_object_names,
        )

    collection_was_missing = status.collection_missing
    collection = get_snapshot_collection()
    history = load_history()
    relinked_snapshot_count = 0
    missing_snapshot_object_names = []
    for commit in all_snapshot_records(history):
        snapshot = bpy.data.objects.get(commit.snapshot_object_name)
        if snapshot is None:
            missing_snapshot_object_names.append(commit.snapshot_object_name)
            continue

        if snapshot.name not in collection.objects:
            collection.objects.link(snapshot)
            relinked_snapshot_count += 1
        snapshot[SNAPSHOT_MARKER_PROP] = True
        snapshot[SNAPSHOT_COMMIT_ID_PROP] = commit.commit_id
        snapshot[OBJECT_UUID_PROP] = commit.object_uuid
        hide_snapshot_object(snapshot)
        remove_snapshot_from_visible_collections(snapshot)

    lock_snapshot_collection(collection)
    lock_snapshot_layer_collections()
    return RepositoryRepairResult(
        repaired_collection=collection_was_missing,
        relinked_snapshot_count=relinked_snapshot_count,
        missing_snapshot_object_names=missing_snapshot_object_names,
    )


def delete_all_history() -> list[CommitRecord]:
    history = load_history()
    removed_commits = all_commits(history)
    for commit in all_snapshot_records(history):
        remove_snapshot_resources(commit)
    save_history(HistoryDocument.empty())
    remove_empty_duplicate_snapshot_collections()
    return removed_commits


def remove_all_snapshot_objects() -> list[str]:
    removed_names = []
    for obj in list(bpy.data.objects):
        if not is_snapshot_object(obj):
            continue
        removed_names.append(obj.name)
        remove_object_if_unused(obj)
    return removed_names


def remove_snapshot_collections() -> list[str]:
    if not hasattr(bpy.data, "collections"):
        return []

    removed_names = []
    for collection in list(bpy.data.collections):
        if collection.name != SNAPSHOT_COLLECTION_NAME and not collection.name.startswith(
            f"{SNAPSHOT_COLLECTION_NAME}."
        ):
            continue

        for obj in list(collection.objects):
            if is_snapshot_object(obj):
                remove_object_if_unused(obj)
            else:
                collection.objects.unlink(obj)
        removed_names.append(collection.name)
        bpy.data.collections.remove(collection)
    return removed_names


def clear_repository_object_properties() -> list[str]:
    cleared_names = []
    for obj in bpy.data.objects:
        cleared = False
        for prop_name in (OBJECT_UUID_PROP, SNAPSHOT_MARKER_PROP, SNAPSHOT_COMMIT_ID_PROP):
            if prop_name not in obj:
                continue
            del obj[prop_name]
            cleared = True
        if cleared:
            cleared_names.append(obj.name)
    return cleared_names


def remove_history_texts() -> int:
    removed_count = 0
    for text in list(bpy.data.texts):
        if text.name != HISTORY_TEXT_NAME and not text.name.startswith(f"{HISTORY_TEXT_NAME}."):
            continue
        bpy.data.texts.remove(text)
        removed_count += 1
    return removed_count


def delete_repository() -> RepositoryDeleteResult:
    history = (
        load_history()
        if bpy.data.texts.get(HISTORY_TEXT_NAME) is not None
        else HistoryDocument.empty()
    )
    removed_commits = all_commits(history)
    for commit in all_snapshot_records(history):
        remove_snapshot_resources(commit)

    removed_snapshot_names = remove_all_snapshot_objects()
    removed_collection_names = remove_snapshot_collections()
    removed_history_text_count = remove_history_texts()
    cleared_object_names = clear_repository_object_properties()

    return RepositoryDeleteResult(
        removed_commit_count=len(removed_commits),
        removed_snapshot_object_count=len(removed_snapshot_names),
        removed_collection_count=len(removed_collection_names),
        cleared_object_count=len(cleared_object_names),
        removed_history_text=removed_history_text_count > 0,
    )


def remove_data_block_if_unused(data: bpy.types.ID | None) -> None:
    if data is None or data.users != 0 or data.library is not None:
        return

    data_collection_name = {
        "Mesh": "meshes",
        "Curve": "curves",
    }.get(data.bl_rna.identifier)
    data_collection = getattr(bpy.data, data_collection_name, None)
    if data_collection is not None and data.name in data_collection:
        data_collection.remove(data)


def capture_material_names(obj: bpy.types.Object) -> list[str | None] | None:
    materials = getattr(obj.data, "materials", None)
    if materials is None:
        return None
    return [material.name if material is not None else None for material in materials]


def capture_material_indices(data: bpy.types.ID) -> tuple[str, list[int]] | None:
    polygons = getattr(data, "polygons", None)
    if polygons is not None:
        return ("polygons", [polygon.material_index for polygon in polygons])

    splines = getattr(data, "splines", None)
    if splines is not None:
        return ("splines", [spline.material_index for spline in splines])

    return None


def restore_material_indices(
    data: bpy.types.ID,
    material_indices: tuple[str, list[int]] | None,
    slot_count: int,
) -> None:
    if material_indices is None or slot_count <= 0:
        return

    collection_name, values = material_indices
    collection = getattr(data, collection_name, None)
    if collection is None:
        return

    max_index = slot_count - 1
    for item, material_index in zip(collection, values, strict=False):
        item.material_index = min(material_index, max_index)


def restore_material_slots(target: bpy.types.Object, commit: CommitRecord) -> list[str]:
    if commit.material_names is None:
        return []

    materials = getattr(target.data, "materials", None)
    if materials is None:
        return []

    material_indices = capture_material_indices(target.data)
    missing_material_names = []
    materials.clear()
    for material_name in commit.material_names:
        if material_name is None:
            materials.append(None)
            continue

        material = bpy.data.materials.get(material_name)
        if material is None:
            missing_material_names.append(material_name)
            materials.append(None)
            continue

        materials.append(material)
    restore_material_indices(target.data, material_indices, len(commit.material_names))
    target.data.update()
    return missing_material_names


def copy_transform_state(target: bpy.types.Object, snapshot: bpy.types.Object) -> None:
    target.location = snapshot.location.copy()
    target.rotation_mode = snapshot.rotation_mode
    target.rotation_euler = snapshot.rotation_euler.copy()
    target.rotation_quaternion = snapshot.rotation_quaternion.copy()
    target.rotation_axis_angle = snapshot.rotation_axis_angle
    target.scale = snapshot.scale.copy()
    target.delta_location = snapshot.delta_location.copy()
    target.delta_rotation_euler = snapshot.delta_rotation_euler.copy()
    target.delta_rotation_quaternion = snapshot.delta_rotation_quaternion.copy()
    target.delta_scale = snapshot.delta_scale.copy()


def safe_copy_value(value):
    if isinstance(value, bpy.types.ID):
        return value
    if hasattr(value, "copy"):
        try:
            return value.copy()
        except (AttributeError, TypeError, ValueError, RuntimeError):
            pass
    try:
        return copy.deepcopy(value)
    except (TypeError, ValueError, RuntimeError):
        return value


def copy_rna_properties(
    source,
    target,
    excluded_properties: set[str] | None = None,
) -> None:
    excluded = RNA_COPY_EXCLUDED_PROPS | (excluded_properties or set())
    for prop in source.bl_rna.properties:
        identifier = prop.identifier
        if identifier in excluded or prop.is_readonly:
            continue
        try:
            value = getattr(source, identifier)
            setattr(target, identifier, safe_copy_value(value))
        except (AttributeError, TypeError, ValueError, RuntimeError):
            continue


def copy_id_properties(
    source,
    target,
    protected_properties: set[str] | None = None,
) -> None:
    protected = protected_properties or set()
    try:
        target_keys = list(target.keys())
        source_keys = list(source.keys())
    except TypeError:
        return

    for key in target_keys:
        if key in protected:
            continue
        try:
            del target[key]
        except (KeyError, TypeError, RuntimeError):
            continue

    for key in source_keys:
        if key in protected:
            continue
        try:
            target[key] = safe_copy_value(source[key])
        except (TypeError, ValueError, RuntimeError):
            continue


def id_collection_for_type(id_type: str):
    collection_name = ID_COLLECTIONS_BY_RNA.get(id_type)
    if collection_name is None:
        return None
    return getattr(bpy.data, collection_name, None)


def resolve_id_reference(id_type: str, name: str):
    collection = id_collection_for_type(id_type)
    if collection is None:
        return None
    return collection.get(name)


def reference_label(item_name: str, property_name: str, reference: dict[str, object]) -> str:
    reference_name = reference.get("name", "")
    if reference_name:
        return f"{item_name}.{property_name} ({reference_name})"
    return f"{item_name}.{property_name}"


def find_reference_metadata(
    references: list[dict[str, object]],
    index: int,
    item_name: str,
    item_type: str,
) -> dict[str, object] | None:
    if index < len(references):
        candidate = references[index]
        if candidate.get("name") == item_name and candidate.get("type") == item_type:
            return candidate

    for candidate in references:
        if candidate.get("name") == item_name and candidate.get("type") == item_type:
            return candidate
    return None


def restore_recorded_references(
    target_item,
    reference_metadata: dict[str, object] | None,
    owner: bpy.types.ID | None = None,
) -> list[str]:
    if not reference_metadata:
        return []

    missing_reference_names = []
    references = reference_metadata.get("references", [])
    if not isinstance(references, list):
        return []

    for reference in references:
        if not isinstance(reference, dict):
            continue
        property_name = reference.get("property")
        id_type = reference.get("id_type")
        name = reference.get("name")
        if not (
            isinstance(property_name, str) and isinstance(id_type, str) and isinstance(name, str)
        ):
            continue
        if not hasattr(target_item, property_name):
            continue

        restored_reference = (
            owner if reference.get("is_self") else resolve_id_reference(id_type, name)
        )
        if restored_reference is None:
            try:
                setattr(target_item, property_name, None)
            except (AttributeError, TypeError, RuntimeError):
                pass
            missing_reference_names.append(
                reference_label(target_item.name, property_name, reference)
            )
            continue

        try:
            setattr(target_item, property_name, restored_reference)
        except (AttributeError, TypeError, ValueError, RuntimeError):
            missing_reference_names.append(
                reference_label(target_item.name, property_name, reference)
            )

    return missing_reference_names


def restore_custom_properties(target: bpy.types.Object, snapshot: bpy.types.Object) -> None:
    copy_id_properties(snapshot, target, protected_properties=SNAPSHOT_INTERNAL_PROPS)


def restore_vertex_groups(target: bpy.types.Object, snapshot: bpy.types.Object) -> None:
    if not hasattr(target, "vertex_groups") or not hasattr(snapshot, "vertex_groups"):
        return

    while target.vertex_groups:
        target.vertex_groups.remove(target.vertex_groups[0])

    for source_group in snapshot.vertex_groups:
        target_group = target.vertex_groups.new(name=source_group.name)
        target_group.lock_weight = source_group.lock_weight

    if target.vertex_groups:
        target.vertex_groups.active_index = min(
            snapshot.vertex_groups.active_index,
            len(target.vertex_groups) - 1,
        )


def restore_modifiers(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> list[str]:
    while target.modifiers:
        target.modifiers.remove(target.modifiers[0])

    object_state = commit.object_state or {}
    reference_metadata = (
        object_state.get("modifier_references") if isinstance(object_state, dict) else None
    )
    references = reference_metadata if isinstance(reference_metadata, list) else []
    missing_reference_names = []

    for index, source_modifier in enumerate(snapshot.modifiers):
        try:
            target_modifier = target.modifiers.new(source_modifier.name, source_modifier.type)
        except RuntimeError:
            continue

        copy_rna_properties(source_modifier, target_modifier, excluded_properties={"type"})
        copy_id_properties(source_modifier, target_modifier)
        item_reference_metadata = find_reference_metadata(
            references,
            index,
            source_modifier.name,
            source_modifier.type,
        )
        missing_reference_names.extend(
            restore_recorded_references(target_modifier, item_reference_metadata, target)
        )

    return missing_reference_names


def restore_constraints(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> list[str]:
    while target.constraints:
        target.constraints.remove(target.constraints[0])

    object_state = commit.object_state or {}
    reference_metadata = (
        object_state.get("constraint_references") if isinstance(object_state, dict) else None
    )
    references = reference_metadata if isinstance(reference_metadata, list) else []
    missing_reference_names = []

    for index, source_constraint in enumerate(snapshot.constraints):
        try:
            target_constraint = target.constraints.new(type=source_constraint.type)
        except RuntimeError:
            continue

        target_constraint.name = source_constraint.name
        copy_rna_properties(source_constraint, target_constraint, excluded_properties={"type"})
        copy_id_properties(source_constraint, target_constraint)
        item_reference_metadata = find_reference_metadata(
            references,
            index,
            source_constraint.name,
            source_constraint.type,
        )
        missing_reference_names.extend(
            restore_recorded_references(target_constraint, item_reference_metadata, target)
        )

    return missing_reference_names


def restore_parent_state(target: bpy.types.Object, snapshot: bpy.types.Object) -> None:
    parent = snapshot.parent
    target.parent = parent if parent is not None and parent.name in bpy.data.objects else None
    target.parent_type = snapshot.parent_type
    target.parent_bone = snapshot.parent_bone
    target.matrix_parent_inverse = snapshot.matrix_parent_inverse.copy()


def copy_named_properties(source, target, property_names: tuple[str, ...]) -> None:
    for property_name in property_names:
        if not hasattr(source, property_name) or not hasattr(target, property_name):
            continue
        try:
            setattr(target, property_name, safe_copy_value(getattr(source, property_name)))
        except (AttributeError, TypeError, ValueError, RuntimeError):
            continue


def restore_object_display_state(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> None:
    copy_named_properties(
        snapshot,
        target,
        (
            "display_type",
            "display_bounds_type",
            "show_name",
            "show_axis",
            "show_texture_space",
            "show_wire",
            "show_in_front",
            "color",
            "pass_index",
            "lock_location",
            "lock_rotation",
            "lock_rotation_w",
            "lock_rotations_4d",
            "lock_scale",
        ),
    )

    object_state = commit.object_state or {}
    visibility = object_state.get("visibility") if isinstance(object_state, dict) else None
    if not isinstance(visibility, dict):
        target.hide_viewport = False
        target.hide_render = False
        target.hide_select = False
        try:
            target.hide_set(False)
        except RuntimeError:
            pass
        return

    target.hide_viewport = bool(visibility.get("hide_viewport", False))
    target.hide_render = bool(visibility.get("hide_render", False))
    if hasattr(target, "hide_select"):
        target.hide_select = bool(visibility.get("hide_select", False))
    try:
        target.hide_set(bool(visibility.get("hide_get", False)))
    except RuntimeError:
        pass


def repair_working_snapshot_metadata(
    target: bpy.types.Object,
    commit: CommitRecord,
) -> bool:
    repaired = False
    for prop_name in (SNAPSHOT_MARKER_PROP, SNAPSHOT_COMMIT_ID_PROP):
        if prop_name not in target:
            continue
        try:
            del target[prop_name]
        except (KeyError, TypeError, RuntimeError):
            continue
        repaired = True

    if not repaired:
        return False

    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    if snapshot is not None:
        restore_object_display_state(target, snapshot, commit)
    return True


def restore_collection_membership(target: bpy.types.Object, commit: CommitRecord) -> None:
    object_state = commit.object_state or {}
    collection_names = (
        object_state.get("collection_names") if isinstance(object_state, dict) else None
    )
    if not isinstance(collection_names, list):
        return

    target_collections = [
        collection
        for collection_name in collection_names
        if isinstance(collection_name, str)
        for collection in (bpy.data.collections.get(collection_name),)
        if collection is not None and collection.name != SNAPSHOT_COLLECTION_NAME
    ]
    if not target_collections:
        target_collections = [bpy.context.scene.collection]

    for collection in list(target.users_collection):
        if collection in target_collections:
            continue
        collection.objects.unlink(target)

    for collection in target_collections:
        if target.name not in collection.objects:
            collection.objects.link(target)


def find_animation_reference_metadata(
    references: list[dict[str, object]],
    data_path: str,
    array_index: int,
) -> dict[str, object] | None:
    for candidate in references:
        if candidate.get("data_path") == data_path and candidate.get("array_index") == array_index:
            return candidate
    return None


def find_driver_target_reference(
    fcurve_reference_metadata: dict[str, object] | None,
    variable_name: str,
    variable_index: int,
    target_index: int,
) -> dict[str, object] | None:
    if fcurve_reference_metadata is None:
        return None

    references = fcurve_reference_metadata.get("references", [])
    if not isinstance(references, list):
        return None

    for reference in references:
        if not isinstance(reference, dict):
            continue
        if (
            reference.get("variable_name") == variable_name
            and reference.get("variable_index") == variable_index
            and reference.get("target_index") == target_index
        ):
            return reference
    return None


def driver_reference_label(
    fcurve,
    variable_name: str,
    target_index: int,
    reference: dict[str, object] | None,
) -> str:
    reference_name = reference.get("name", "") if reference else ""
    target_label = f"{fcurve.data_path}[{fcurve.array_index}].{variable_name}[{target_index}]"
    if reference_name:
        return f"{target_label} ({reference_name})"
    return target_label


def copy_driver_target(
    source_target,
    target_target,
    owner: bpy.types.Object,
    fcurve,
    variable_name: str,
    variable_index: int,
    target_index: int,
    fcurve_reference_metadata: dict[str, object] | None,
) -> str | None:
    reference = find_driver_target_reference(
        fcurve_reference_metadata,
        variable_name,
        variable_index,
        target_index,
    )

    copy_rna_properties(source_target, target_target, excluded_properties={"id"})
    restored_reference = None
    if reference is not None:
        id_type = reference.get("id_type")
        name = reference.get("name")
        if reference.get("is_self"):
            restored_reference = owner
        elif isinstance(id_type, str) and isinstance(name, str):
            restored_reference = resolve_id_reference(id_type, name)
    elif source_target.id == owner:
        restored_reference = owner
    elif source_target.id is not None and source_target.id.name in bpy.data.objects:
        restored_reference = source_target.id

    if restored_reference is None:
        return driver_reference_label(fcurve, variable_name, target_index, reference)

    try:
        target_target.id = restored_reference
    except (AttributeError, TypeError, ValueError, RuntimeError):
        return driver_reference_label(fcurve, variable_name, target_index, reference)

    return None


def copy_driver_variables(
    source_fcurve,
    target_fcurve,
    owner: bpy.types.Object,
    fcurve_reference_metadata: dict[str, object] | None,
) -> list[str]:
    missing_reference_names = []
    source_driver = source_fcurve.driver
    target_driver = target_fcurve.driver

    for variable in list(target_driver.variables):
        target_driver.variables.remove(variable)

    for variable_index, source_variable in enumerate(source_driver.variables):
        target_variable = target_driver.variables.new()
        target_variable.name = source_variable.name
        target_variable.type = source_variable.type
        copy_rna_properties(source_variable, target_variable, excluded_properties={"name", "type"})

        for target_index, source_target in enumerate(source_variable.targets):
            if target_index >= len(target_variable.targets):
                continue
            missing_reference = copy_driver_target(
                source_target,
                target_variable.targets[target_index],
                owner,
                source_fcurve,
                source_variable.name,
                variable_index,
                target_index,
                fcurve_reference_metadata,
            )
            if missing_reference:
                missing_reference_names.append(missing_reference)

    target_driver.type = source_driver.type
    target_driver.expression = source_driver.expression
    if hasattr(source_driver, "use_self") and hasattr(target_driver, "use_self"):
        target_driver.use_self = source_driver.use_self

    return missing_reference_names


def restore_drivers(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> list[str]:
    source_animation_data = snapshot.animation_data
    if source_animation_data is None:
        return []

    object_state = commit.object_state or {}
    reference_metadata = (
        object_state.get("animation_references") if isinstance(object_state, dict) else None
    )
    references = reference_metadata if isinstance(reference_metadata, list) else []
    missing_reference_names = []

    for source_fcurve in source_animation_data.drivers:
        try:
            target_fcurve = target.driver_add(source_fcurve.data_path, source_fcurve.array_index)
        except (TypeError, ValueError, RuntimeError):
            continue

        copy_rna_properties(
            source_fcurve,
            target_fcurve,
            excluded_properties={"data_path", "array_index", "driver", "group"},
        )
        fcurve_reference_metadata = find_animation_reference_metadata(
            references,
            source_fcurve.data_path,
            source_fcurve.array_index,
        )
        missing_reference_names.extend(
            copy_driver_variables(
                source_fcurve,
                target_fcurve,
                target,
                fcurve_reference_metadata,
            )
        )

    return missing_reference_names


def capture_nla_action_names(animation_data) -> list[list[str | None]]:
    if animation_data is None:
        return []
    return [
        [strip.action.name if strip.action is not None else None for strip in track.strips]
        for track in animation_data.nla_tracks
    ]


def restore_nla_tracks(
    target_animation_data,
    source_animation_data,
    preferred_action_names: list[list[str | None]],
) -> None:
    for track_index, source_track in enumerate(source_animation_data.nla_tracks):
        target_track = target_animation_data.nla_tracks.new()
        target_track.name = source_track.name
        copy_rna_properties(source_track, target_track, excluded_properties={"strips"})

        for strip_index, source_strip in enumerate(source_track.strips):
            preferred_name = (
                preferred_action_names[track_index][strip_index]
                if track_index < len(preferred_action_names)
                and strip_index < len(preferred_action_names[track_index])
                else None
            )
            action = make_restore_action_copy(source_strip.action, preferred_name)
            if action is None:
                continue
            try:
                target_strip = target_track.strips.new(
                    source_strip.name,
                    int(round(source_strip.frame_start)),
                    action,
                )
            except RuntimeError:
                continue
            copy_rna_properties(
                source_strip,
                target_strip,
                excluded_properties={
                    "action",
                    "action_slot",
                    "action_slot_handle",
                    "action_suitable_slots",
                    "last_slot_identifier",
                    "strips",
                    "type",
                },
            )


def restore_animation_data(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> list[str]:
    source_animation_data = snapshot.animation_data
    existing_animation_data = target.animation_data
    preferred_action_name = (
        existing_animation_data.action.name
        if existing_animation_data is not None and existing_animation_data.action is not None
        else None
    )
    preferred_nla_action_names = capture_nla_action_names(existing_animation_data)
    existing_actions = capture_animation_actions(existing_animation_data)
    target.animation_data_clear()
    for action in existing_actions:
        remove_action_if_unused(action)
    if source_animation_data is None:
        return []

    target_animation_data = target.animation_data_create()
    copy_named_properties(
        source_animation_data,
        target_animation_data,
        (
            "action_blend_type",
            "action_extrapolation",
            "action_influence",
            "use_nla",
        ),
    )

    if source_animation_data.action is not None:
        target_animation_data.action = make_restore_action_copy(
            source_animation_data.action,
            preferred_action_name,
        )

    restore_nla_tracks(target_animation_data, source_animation_data, preferred_nla_action_names)
    return restore_drivers(target, snapshot, commit)


def restore_object_state(
    target: bpy.types.Object,
    snapshot: bpy.types.Object,
    commit: CommitRecord,
) -> list[str]:
    missing_reference_names = []
    restore_vertex_groups(target, snapshot)
    missing_reference_names.extend(restore_modifiers(target, snapshot, commit))
    missing_reference_names.extend(restore_constraints(target, snapshot, commit))
    restore_parent_state(target, snapshot)
    restore_custom_properties(target, snapshot)
    restore_object_display_state(target, snapshot, commit)
    restore_collection_membership(target, commit)
    missing_reference_names.extend(restore_animation_data(target, snapshot, commit))
    return missing_reference_names


def restore_data_block(target: bpy.types.Object, snapshot: bpy.types.Object) -> None:
    if target.type != snapshot.type:
        msg = f"Cannot restore {snapshot.type} snapshot to {target.type} object."
        raise ValueError(msg)

    old_data = target.data
    old_data_name = old_data.name if old_data is not None else None
    target.data = snapshot.data.copy() if snapshot.data is not None else None
    remove_data_block_if_unused(old_data)
    if target.data is not None and old_data_name:
        target.data.name = old_data_name


def restore_commit(
    target: bpy.types.Object,
    commit: CommitRecord,
) -> RestoreResult:
    snapshot = bpy.data.objects.get(commit.snapshot_object_name)
    if snapshot is None:
        msg = f"Snapshot object not found: {commit.snapshot_object_name}"
        raise ValueError(msg)

    restore_data_block(target, snapshot)
    missing_material_names = restore_material_slots(target, commit)
    copy_transform_state(target, snapshot)
    missing_reference_names = restore_object_state(target, snapshot, commit)
    target[OBJECT_UUID_PROP] = commit.object_uuid
    if SNAPSHOT_MARKER_PROP in target:
        del target[SNAPSHOT_MARKER_PROP]
    if SNAPSHOT_COMMIT_ID_PROP in target:
        del target[SNAPSHOT_COMMIT_ID_PROP]

    bpy.context.view_layer.objects.active = target
    target.select_set(True)
    return RestoreResult(
        obj=target,
        missing_material_names=missing_material_names,
        missing_reference_names=missing_reference_names,
    )

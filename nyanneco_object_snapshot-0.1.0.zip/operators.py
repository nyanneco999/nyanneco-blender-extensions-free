from __future__ import annotations

import bpy

from .constants import OBJECT_UUID_PROP, SUPPORTED_OBJECT_TYPES
from .features import (
    FEATURE_ARCHIVE,
    FEATURE_BATCH_OPERATIONS,
    FEATURE_BRANCH,
    FEATURE_MERGE,
    feature_disabled_issue,
    is_feature_enabled,
)
from .preview import clear_preview_cache
from .selection import (
    clear_selected_archived_commit_ids,
    clear_selected_commit_ids,
    selected_archived_commit_ids,
    selected_commit_ids,
    set_selected_archived_commit_ids,
    set_selected_commit_ids,
)
from .storage import (
    archive_commit,
    cleanup_redundant_commit_drafts,
    delete_all_commits,
    delete_all_history,
    delete_commit,
    delete_commit_draft,
    delete_repository,
    fork_commit,
    get_linked_object_issue,
    has_history_entries,
    load_history,
    load_history_readonly,
    merge_fork_history,
    object_differs_from_commit,
    regenerate_thumbnail_cache,
    repair_duplicate_object_uuids,
    repair_repository_collection,
    repair_working_snapshot_metadata,
    repository_integrity_status,
    restore_commit,
    save_history,
    store_commit,
    store_commit_draft,
    unarchive_commit,
    update_commit_message,
)
from .translations import iface_format, iface_text
from .ui import draw_commit_list


def active_supported_object(context: bpy.types.Context) -> bpy.types.Object | None:
    obj = context.object
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        return None
    return obj


def active_object_mode_supported_object(context: bpy.types.Context) -> bpy.types.Object | None:
    obj = active_supported_object(context)
    if obj is None or obj.mode != "OBJECT":
        return None
    return obj


def poll_object_mode_snapshot_action(cls, context: bpy.types.Context) -> bool:
    obj = active_supported_object(context)
    if obj is None:
        return False
    if obj.mode != "OBJECT":
        cls.poll_message_set("Object Snapshot actions are available in Object Mode only.")
        return False
    return True


def report_object_mode_required(operator: bpy.types.Operator, context: bpy.types.Context) -> bool:
    obj = active_supported_object(context)
    if obj is not None and obj.mode != "OBJECT":
        operator.report(
            {"ERROR"},
            iface_text("Object Snapshot actions are available in Object Mode only."),
        )
        return False
    return True


def get_active_object_history(context: bpy.types.Context):
    obj = active_supported_object(context)
    if obj is None:
        return None

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return None

    return load_history_readonly().objects.get(str(object_uuid))


def store_dirty_active_commit_draft(obj: bpy.types.Object, object_history) -> None:
    active_commit_id = object_history.active_commit_id if object_history is not None else None
    if active_commit_id is None:
        return

    object_uuid = str(obj.get(OBJECT_UUID_PROP, ""))
    if not object_uuid:
        return

    from . import handlers

    commit = object_history.get_commit(str(active_commit_id))
    if commit is None:
        return

    repair_working_snapshot_metadata(obj, commit)
    draft_commit = object_history.draft_commits.get(str(active_commit_id))
    if not object_differs_from_commit(obj, commit):
        if draft_commit is not None:
            delete_commit_draft(object_uuid, str(active_commit_id))
            clear_preview_cache()
        handlers.clear_commit_draft_dirty(object_uuid, str(active_commit_id))
        return

    if draft_commit is not None and not object_differs_from_commit(obj, draft_commit):
        handlers.clear_commit_draft_dirty(object_uuid, str(active_commit_id))
        return

    store_commit_draft(obj, str(active_commit_id))
    clear_preview_cache()
    handlers.clear_commit_draft_dirty(object_uuid, str(active_commit_id))


def draw_delete_confirmation(
    layout: bpy.types.UILayout,
    confirmed_once: bool,
    first_message: str,
    second_message: str,
) -> None:
    icon = "ERROR" if confirmed_once else "QUESTION"
    message = second_message if confirmed_once else first_message
    layout.label(text=iface_text(message), icon=icon)
    if confirmed_once:
        layout.label(text=iface_text("This action cannot be undone from the add-on."))
    else:
        layout.label(text=iface_text("A second confirmation will be required."))


def tag_redraw_all_areas(context: bpy.types.Context) -> None:
    screen = getattr(context, "screen", None)
    if screen is None:
        return
    for area in screen.areas:
        area.tag_redraw()


def poll_feature(cls, feature: str) -> bool:
    if is_feature_enabled(feature):
        return True
    cls.poll_message_set("This feature is available in the paid version.")
    return False


def report_feature_unavailable(operator: bpy.types.Operator, feature: str) -> bool:
    issue = feature_disabled_issue(feature)
    if issue is None:
        return False
    operator.report({"WARNING"}, iface_format(issue.message, **issue.kwargs))
    return True


class NYANNECO_OT_object_snapshot_toggle_scene_bool(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.toggle_scene_bool"
    bl_label = "Toggle Object Snapshot UI Section"
    bl_description = "Toggle an Object Snapshot UI section"
    bl_options = {"REGISTER"}

    prop_name: bpy.props.StringProperty(name="Property Name", default="")

    def execute(self, context: bpy.types.Context):
        if not self.prop_name or not hasattr(context.scene, self.prop_name):
            return {"CANCELLED"}

        current_value = bool(getattr(context.scene, self.prop_name))
        setattr(context.scene, self.prop_name, not current_value)
        tag_redraw_all_areas(context)
        return {"FINISHED"}


def visible_commit_ids_for_selection(context: bpy.types.Context, object_history) -> list[str]:
    archived_commit_ids = set(object_history.archived_commit_ids)
    commits = list(reversed(object_history.commits))
    main_commits = [commit for commit in commits if commit.commit_id not in archived_commit_ids]

    visible_commits = main_commits[:5]
    if context.scene.nyanneco_object_snapshot_show_older_commits:
        visible_commits.extend(main_commits[5:])
    return [commit.commit_id for commit in visible_commits]


def visible_archived_commit_ids_for_selection(
    context: bpy.types.Context, object_history
) -> list[str]:
    if not context.scene.nyanneco_object_snapshot_show_archived_commits:
        return []

    archived_commit_ids = set(object_history.archived_commit_ids)
    return [
        commit.commit_id
        for commit in reversed(object_history.commits)
        if commit.commit_id in archived_commit_ids
    ]


def main_commit_ids_for_selection(object_history) -> set[str]:
    archived_commit_ids = set(object_history.archived_commit_ids)
    return {
        commit.commit_id
        for commit in object_history.commits
        if commit.commit_id not in archived_commit_ids
    }


def archived_commit_ids_for_selection(object_history) -> set[str]:
    archived_commit_ids = set(object_history.archived_commit_ids)
    return {
        commit.commit_id
        for commit in object_history.commits
        if commit.commit_id in archived_commit_ids
    }


class NYANNECO_OT_object_snapshot_toggle_select(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.toggle_select"
    bl_label = "Toggle Snapshot Selection"
    bl_description = "Toggle this snapshot for batch operations"
    bl_options = {"REGISTER"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")
    archived: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and active_supported_object(context) is not None
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        if not self.commit_id:
            return {"CANCELLED"}

        from .selection import toggle_selected_archived_commit_id, toggle_selected_commit_id

        if self.archived:
            toggle_selected_archived_commit_id(context.scene, self.commit_id)
        else:
            toggle_selected_commit_id(context.scene, self.commit_id)
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_select_visible(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.select_visible"
    bl_label = "Select Visible Snapshots"
    bl_description = "Select all currently visible snapshots for batch operations"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and active_supported_object(context) is not None
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        object_history = get_active_object_history(context)
        if object_history is None:
            return {"CANCELLED"}

        set_selected_commit_ids(
            context.scene,
            selected_commit_ids(context.scene)
            | set(visible_commit_ids_for_selection(context, object_history)),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_clear_selection(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.clear_selection"
    bl_label = "Clear Snapshot Selection"
    bl_description = "Clear all checked snapshots"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_feature(cls, FEATURE_BATCH_OPERATIONS)

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        clear_selected_commit_ids(context.scene)
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_select_visible_archived(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.select_visible_archived"
    bl_label = "Select Visible Archived Snapshots"
    bl_description = "Select all currently visible archived snapshots for batch operations"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and active_supported_object(context) is not None
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        object_history = get_active_object_history(context)
        if object_history is None:
            return {"CANCELLED"}

        set_selected_archived_commit_ids(
            context.scene,
            selected_archived_commit_ids(context.scene)
            | set(visible_archived_commit_ids_for_selection(context, object_history)),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_clear_archived_selection(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.clear_archived_selection"
    bl_label = "Clear Archived Snapshot Selection"
    bl_description = "Clear all checked archived snapshots"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_feature(cls, FEATURE_BATCH_OPERATIONS)

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        clear_selected_archived_commit_ids(context.scene)
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_archive_selected(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.archive_selected"
    bl_label = "Archive Selected Snapshots"
    bl_description = "Archive all checked snapshots"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and poll_feature(cls, FEATURE_ARCHIVE)
            and active_supported_object(context) is not None
        )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        if context.scene.nyanneco_object_snapshot_confirm_archive:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        object_history = get_active_object_history(context)
        if object_history is None:
            self.report({"ERROR"}, iface_text("No snapshots are checked."))
            return {"CANCELLED"}

        selected_ids = selected_commit_ids(context.scene) & main_commit_ids_for_selection(
            object_history
        )
        if not object_uuid or not selected_ids:
            self.report({"ERROR"}, iface_text("No snapshots are checked."))
            return {"CANCELLED"}

        archived_count = 0
        for commit_id in selected_ids:
            if archive_commit(str(object_uuid), commit_id):
                archived_count += 1

        clear_selected_commit_ids(context.scene)
        self.report(
            {"INFO"},
            iface_format("Archived {count} snapshots.", count=archived_count),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete_selected(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete_selected"
    bl_label = "Delete Selected Snapshots"
    bl_description = "Delete all checked snapshots"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and active_supported_object(context) is not None
        )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Delete checked snapshots?",
            "Really delete checked snapshots?",
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        object_history = get_active_object_history(context)
        if object_history is None:
            self.report({"ERROR"}, iface_text("No snapshots are checked."))
            return {"CANCELLED"}

        selected_ids = selected_commit_ids(context.scene) & main_commit_ids_for_selection(
            object_history
        )
        if not object_uuid or not selected_ids:
            self.report({"ERROR"}, iface_text("No snapshots are checked."))
            return {"CANCELLED"}

        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        deleted_count = 0
        for commit_id in list(selected_ids):
            if delete_commit(str(object_uuid), commit_id) is not None:
                deleted_count += 1

        clear_selected_commit_ids(context.scene)
        self.report(
            {"INFO"},
            iface_format("Deleted {count} checked snapshots.", count=deleted_count),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_unarchive_selected(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.unarchive_selected"
    bl_label = "Unarchive Selected Snapshots"
    bl_description = "Return all checked archived snapshots to the main history list"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and poll_feature(cls, FEATURE_ARCHIVE)
            and active_supported_object(context) is not None
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        object_history = get_active_object_history(context)
        if object_history is None:
            self.report({"ERROR"}, iface_text("No archived snapshots are checked."))
            return {"CANCELLED"}

        selected_ids = selected_archived_commit_ids(
            context.scene
        ) & archived_commit_ids_for_selection(object_history)
        if not object_uuid or not selected_ids:
            self.report({"ERROR"}, iface_text("No archived snapshots are checked."))
            return {"CANCELLED"}

        unarchived_count = 0
        for commit_id in selected_ids:
            if unarchive_commit(str(object_uuid), commit_id):
                unarchived_count += 1

        clear_selected_archived_commit_ids(context.scene)
        self.report(
            {"INFO"},
            iface_format("Unarchived {count} snapshots.", count=unarchived_count),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete_selected_archived(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete_selected_archived"
    bl_label = "Delete Selected Archived Snapshots"
    bl_description = "Delete all checked archived snapshots"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return (
            poll_feature(cls, FEATURE_BATCH_OPERATIONS)
            and active_supported_object(context) is not None
        )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Delete checked archived snapshots?",
            "Really delete checked archived snapshots?",
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BATCH_OPERATIONS):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        object_history = get_active_object_history(context)
        if object_history is None:
            self.report({"ERROR"}, iface_text("No archived snapshots are checked."))
            return {"CANCELLED"}

        selected_ids = selected_archived_commit_ids(
            context.scene
        ) & archived_commit_ids_for_selection(object_history)
        if not object_uuid or not selected_ids:
            self.report({"ERROR"}, iface_text("No archived snapshots are checked."))
            return {"CANCELLED"}

        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        deleted_count = 0
        for commit_id in list(selected_ids):
            if delete_commit(str(object_uuid), commit_id) is not None:
                deleted_count += 1

        clear_selected_archived_commit_ids(context.scene)
        self.report(
            {"INFO"},
            iface_format("Deleted {count} checked archived snapshots.", count=deleted_count),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_commit(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.commit"
    bl_label = "Commit Object Snapshot"
    bl_description = "Store the active object's current state as a hidden snapshot"
    bl_options = {"REGISTER", "UNDO"}

    message: bpy.props.StringProperty(
        name="Message",
        description="Short note for this snapshot",
        default="",
    )

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_object_mode_snapshot_action(cls, context)

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context: bpy.types.Context):
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}

        repair_duplicate_object_uuids()
        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}
        linked_issue = get_linked_object_issue(obj)
        if linked_issue is not None:
            self.report({"WARNING"}, iface_text(linked_issue))
            return {"CANCELLED"}

        history = load_history()
        object_history = history.objects.get(str(obj.get(OBJECT_UUID_PROP, "")))
        active_commit_id = object_history.active_commit_id if object_history is not None else None
        try:
            commit = store_commit(obj, self.message, activate=True)
        except ValueError as exc:
            self.report({"WARNING"}, str(exc))
            return {"CANCELLED"}
        clear_preview_cache()
        if active_commit_id is not None:
            from . import handlers

            handlers.clear_commit_draft_dirty(str(commit.object_uuid), str(active_commit_id))
        self.report(
            {"INFO"},
            iface_format("Snapshot committed: {created_at}", created_at=commit.created_at),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_restore(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.restore"
    bl_label = "Restore Object Snapshot"
    bl_description = "Restore the active object to the selected snapshot"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_object_mode_snapshot_action(cls, context)

    def execute(self, context: bpy.types.Context):
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}

        repair_duplicate_object_uuids()
        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}
        linked_issue = get_linked_object_issue(obj)
        if linked_issue is not None:
            self.report({"WARNING"}, iface_text(linked_issue))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}

        commit_id = self.commit_id or context.scene.nyanneco_object_snapshot_selected_commit
        if not commit_id:
            self.report({"ERROR"}, iface_text("Select a snapshot to restore."))
            return {"CANCELLED"}

        cleanup_redundant_commit_drafts(str(object_uuid))
        history = load_history()
        commit = history.get_commit(str(object_uuid), commit_id)
        if commit is None:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        object_history = history.objects.get(str(object_uuid))
        if object_history is not None:
            store_dirty_active_commit_draft(obj, object_history)

        history = load_history()
        object_history = history.objects.get(commit.object_uuid)
        restore_record = (
            object_history.draft_commits.get(commit.commit_id)
            if object_history is not None
            else None
        ) or commit

        try:
            result = restore_commit(obj, restore_record)
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        history = load_history()
        object_history = history.objects.get(commit.object_uuid)
        if object_history is not None:
            object_history.active_commit_id = commit.commit_id
            history.ensure_object(commit.object_uuid, result.obj.name)
            save_history(history)
            from . import handlers

            handlers.suppress_commit_draft_dirty(commit.object_uuid, commit.commit_id)

        if result.missing_material_names:
            self.report(
                {"WARNING"},
                iface_text("Missing materials were restored as empty slots:")
                + " "
                + ", ".join(result.missing_material_names),
            )
        if result.missing_reference_names:
            self.report(
                {"WARNING"},
                iface_text("Missing references were cleared:")
                + " "
                + ", ".join(result.missing_reference_names),
            )
        self.report(
            {"INFO"},
            iface_format("Snapshot restored: {created_at}", created_at=commit.created_at),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_discard_draft(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.discard_draft"
    bl_label = "Discard Snapshot Draft"
    bl_description = "Discard the temporary draft for the selected snapshot"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")
    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_object_mode_snapshot_action(cls, context)

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Discard this draft?",
            "Really discard this draft?",
        )

    def execute(self, context: bpy.types.Context):
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}
        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid or not self.commit_id:
            self.report({"ERROR"}, iface_text("Snapshot draft was not found."))
            return {"CANCELLED"}

        removed = delete_commit_draft(str(object_uuid), self.commit_id)
        if removed is None:
            self.report({"ERROR"}, iface_text("Snapshot draft was not found."))
            return {"CANCELLED"}
        clear_preview_cache()

        history = load_history()
        object_history = history.objects.get(str(object_uuid))
        if object_history is not None and object_history.active_commit_id == self.commit_id:
            commit = history.get_commit(str(object_uuid), self.commit_id)
            if commit is not None:
                try:
                    result = restore_commit(obj, commit)
                except ValueError as exc:
                    self.report({"ERROR"}, str(exc))
                    return {"CANCELLED"}
                object_history.active_commit_id = commit.commit_id
                history.ensure_object(commit.object_uuid, result.obj.name)
                save_history(history)
                from . import handlers

                handlers.suppress_commit_draft_dirty(commit.object_uuid, commit.commit_id)

        self.report({"INFO"}, iface_text("Snapshot draft discarded."))
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_history(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.history"
    bl_label = "Object Snapshot History"
    bl_description = "Show snapshots for the active object"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return active_supported_object(context) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        object_history = get_active_object_history(context)
        if object_history and object_history.commits:
            context.scene.nyanneco_object_snapshot_selected_commit = (
                object_history.active_commit_id or object_history.commits[-1].commit_id
            )
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context: bpy.types.Context) -> None:
        layout = self.layout
        obj = active_supported_object(context)
        if obj is None:
            layout.label(text=iface_text("Select a mesh or curve object."), icon="ERROR")
            return

        if obj.mode != "OBJECT":
            layout.label(
                text=iface_text("Object Snapshot actions are available in Object Mode only."),
                icon="INFO",
            )

        object_history = get_active_object_history(context)
        if object_history is None or not object_history.commits:
            layout.label(text=iface_text("No snapshots for this object."), icon="INFO")
            layout.operator_context = "INVOKE_DEFAULT"
            layout.operator("nyanneco_object_snapshot.commit", icon="FILE_TICK")
            return

        draw_commit_list(layout, context, object_history)

    def execute(self, context: bpy.types.Context):
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete"
    bl_label = "Delete Object Snapshot"
    bl_description = "Delete the selected object snapshot"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return active_supported_object(context) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context: bpy.types.Context):
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}

        repair_duplicate_object_uuids()
        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}

        if not self.commit_id:
            self.report({"ERROR"}, iface_text("Select a snapshot to delete."))
            return {"CANCELLED"}

        removed = delete_commit(str(object_uuid), self.commit_id)
        if removed is None:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format("Snapshot deleted: {created_at}", created_at=removed.created_at),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_archive(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.archive"
    bl_label = "Archive Object Snapshot"
    bl_description = "Move the selected snapshot out of the main history list"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_feature(cls, FEATURE_ARCHIVE) and active_supported_object(context) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        if context.scene.nyanneco_object_snapshot_confirm_archive:
            return context.window_manager.invoke_confirm(self, event)
        return self.execute(context)

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid or not self.commit_id:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        if not archive_commit(str(object_uuid), self.commit_id):
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        set_selected_commit_ids(
            context.scene, selected_commit_ids(context.scene) - {self.commit_id}
        )
        self.report({"INFO"}, iface_text("Snapshot archived."))
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_unarchive(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.unarchive"
    bl_label = "Unarchive Object Snapshot"
    bl_description = "Return the selected snapshot to the main history list"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_feature(cls, FEATURE_ARCHIVE) and active_supported_object(context) is not None

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_ARCHIVE):
            return {"CANCELLED"}
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid or not self.commit_id:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        if not unarchive_commit(str(object_uuid), self.commit_id):
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        set_selected_archived_commit_ids(
            context.scene, selected_archived_commit_ids(context.scene) - {self.commit_id}
        )
        self.report({"INFO"}, iface_text("Snapshot unarchived."))
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_remessage(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.remessage"
    bl_label = "Edit Snapshot Message"
    bl_description = "Edit the selected snapshot message"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")
    message: bpy.props.StringProperty(
        name="Message",
        description="Short note for this snapshot",
        default="",
    )

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return active_supported_object(context) is not None

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        commit = self.find_commit(context)
        if commit is None:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        self.message = commit.message
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        self.layout.prop(self, "message")

    def find_commit(self, context: bpy.types.Context):
        obj = active_supported_object(context)
        if obj is None:
            return None

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid or not self.commit_id:
            return None

        return load_history().get_commit(str(object_uuid), self.commit_id)

    def execute(self, context: bpy.types.Context):
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}
        if not self.commit_id:
            self.report({"ERROR"}, iface_text("Select a snapshot to edit."))
            return {"CANCELLED"}

        commit = update_commit_message(str(object_uuid), self.commit_id, self.message)
        if commit is None:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format("Snapshot message updated: {created_at}", created_at=commit.created_at),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_fork(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.fork"
    bl_label = "Branch Object Snapshot"
    bl_description = "Create a new editable branch object from the selected snapshot"
    bl_options = {"REGISTER", "UNDO"}

    commit_id: bpy.props.StringProperty(name="Commit ID", default="")

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return poll_feature(cls, FEATURE_BRANCH) and poll_object_mode_snapshot_action(cls, context)

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_BRANCH):
            return {"CANCELLED"}
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}

        repair_duplicate_object_uuids()
        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}
        linked_issue = get_linked_object_issue(obj)
        if linked_issue is not None:
            self.report({"WARNING"}, iface_text(linked_issue))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}

        if not self.commit_id:
            self.report({"ERROR"}, iface_text("Select a snapshot to branch."))
            return {"CANCELLED"}

        history = load_history()
        commit = history.get_commit(str(object_uuid), self.commit_id)
        if commit is None:
            self.report({"ERROR"}, iface_text("Snapshot history entry was not found."))
            return {"CANCELLED"}

        try:
            result = fork_commit(
                obj,
                commit,
                context.collection,
                message=iface_format(
                    "Branched from {source_object_name}",
                    source_object_name=commit.source_object_name,
                ),
            )
        except ValueError as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}

        if result.missing_material_names:
            self.report(
                {"WARNING"},
                iface_text("Missing materials were restored as empty slots:")
                + " "
                + ", ".join(result.missing_material_names),
            )

        self.report(
            {"INFO"},
            iface_format("Snapshot branched as: {object_name}", object_name=result.obj.name),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_merge_fork(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.merge_fork"
    bl_label = "Merge Branch Object History"
    bl_description = "Merge this branch object's new history back to its source object"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        if not poll_feature(cls, FEATURE_MERGE):
            return False
        if not poll_object_mode_snapshot_action(cls, context):
            return False
        object_history = get_active_object_history(context)
        if object_history is None or not object_history.branch_source_object_uuid:
            cls.poll_message_set("The selected object is not a branched snapshot object.")
            return False
        return True

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        if report_feature_unavailable(self, FEATURE_MERGE):
            return {"CANCELLED"}
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Merge this branch back to its source object?",
            "Really merge this branch and remove the branch object?",
        )

    def execute(self, context: bpy.types.Context):
        if report_feature_unavailable(self, FEATURE_MERGE):
            return {"CANCELLED"}
        if not report_object_mode_required(self, context):
            return {"CANCELLED"}
        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        repair_duplicate_object_uuids()
        obj = active_object_mode_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        try:
            result = merge_fork_history(obj)
        except ValueError as exc:
            self.report({"ERROR"}, iface_text(str(exc)))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format(
                "Merged {merged_count} new snapshots into {object_name}.",
                merged_count=result.merged_commit_count,
                object_name=result.target_object.name,
            ),
        )
        tag_redraw_all_areas(context)
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_regenerate_object_thumbnails(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.regenerate_object_thumbnails"
    bl_label = "Regenerate Selected Object Thumbnails"
    bl_description = "Regenerate thumbnail cache for the selected object's history"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        object_history = get_active_object_history(context)
        return object_history is not None and bool(object_history.commits)

    def execute(self, context: bpy.types.Context):
        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}

        result = regenerate_thumbnail_cache(object_uuid=str(object_uuid), force=True)
        clear_preview_cache()
        tag_redraw_all_areas(context)
        if result.generated_count == 0:
            self.report({"WARNING"}, iface_text("No thumbnails were regenerated."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format(
                "Regenerated {count} thumbnails.",
                count=result.generated_count,
            ),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete_object_history(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete_object_history"
    bl_label = "Delete Selected Object History"
    bl_description = "Delete all snapshot history for the selected object"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        object_history = get_active_object_history(context)
        return object_history is not None and bool(object_history.commits)

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Delete all history for the selected object?",
            "Really delete all history for the selected object?",
        )

    def execute(self, context: bpy.types.Context):
        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        obj = active_supported_object(context)
        if obj is None:
            self.report({"ERROR"}, iface_text("Select a mesh or curve object."))
            return {"CANCELLED"}

        object_uuid = obj.get(OBJECT_UUID_PROP)
        if not object_uuid:
            self.report({"ERROR"}, iface_text("The selected object has no snapshot history."))
            return {"CANCELLED"}

        removed_commits = delete_all_commits(str(object_uuid))
        if not removed_commits:
            self.report({"INFO"}, iface_text("No snapshots for this object."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format(
                "Deleted {count} selected object history entries.", count=len(removed_commits)
            ),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete_all(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete_all"
    bl_label = "Delete All History"
    bl_description = "Delete all snapshot history for all objects"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return has_history_entries()

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Delete all history for all objects?",
            "Really delete all history for all objects?",
        )

    def execute(self, context: bpy.types.Context):
        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        removed_commits = delete_all_history()
        if not removed_commits:
            self.report({"INFO"}, iface_text("No snapshot history to delete."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format("Deleted {count} history entries.", count=len(removed_commits)),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_delete_repository(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.delete_repository"
    bl_label = "Delete Repository"
    bl_description = "Delete the snapshot repository and clear object snapshot IDs"
    bl_options = {"REGISTER", "UNDO"}

    confirmed_once: bpy.props.BoolProperty(default=False, options={"HIDDEN"})

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        self.confirmed_once = False
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context: bpy.types.Context) -> None:
        draw_delete_confirmation(
            self.layout,
            self.confirmed_once,
            "Delete the entire snapshot repository?",
            "Really delete the entire snapshot repository?",
        )

    def execute(self, context: bpy.types.Context):
        if not self.confirmed_once:
            self.confirmed_once = True
            return context.window_manager.invoke_props_dialog(self, width=440)

        result = delete_repository()
        if (
            result.removed_commit_count == 0
            and result.removed_snapshot_object_count == 0
            and result.removed_collection_count == 0
            and result.cleared_object_count == 0
            and not result.removed_history_text
        ):
            self.report({"INFO"}, iface_text("No snapshot repository data to delete."))
            return {"CANCELLED"}

        self.report(
            {"INFO"},
            iface_format(
                "Snapshot repository deleted: {count} history entries.",
                count=result.removed_commit_count,
            ),
        )
        return {"FINISHED"}


class NYANNECO_OT_object_snapshot_repair_repository(bpy.types.Operator):
    bl_idname = "nyanneco_object_snapshot.repair_repository"
    bl_label = "Repair Snapshot Repository"
    bl_description = "Recreate the snapshot repository collection and relink snapshot objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        return repository_integrity_status().can_repair

    def execute(self, context: bpy.types.Context):
        result = repair_repository_collection()
        tag_redraw_all_areas(context)
        if result.missing_snapshot_object_names:
            self.report(
                {"WARNING"},
                iface_format(
                    "Snapshot repository repair incomplete: {count} snapshot objects are missing.",
                    count=len(result.missing_snapshot_object_names),
                ),
            )
            return {"FINISHED"}

        self.report(
            {"INFO"},
            iface_format(
                "Snapshot repository repaired: {count} snapshot objects relinked.",
                count=result.relinked_snapshot_count,
            ),
        )
        return {"FINISHED"}


CLASSES = (
    NYANNECO_OT_object_snapshot_toggle_scene_bool,
    NYANNECO_OT_object_snapshot_toggle_select,
    NYANNECO_OT_object_snapshot_select_visible,
    NYANNECO_OT_object_snapshot_clear_selection,
    NYANNECO_OT_object_snapshot_select_visible_archived,
    NYANNECO_OT_object_snapshot_clear_archived_selection,
    NYANNECO_OT_object_snapshot_archive_selected,
    NYANNECO_OT_object_snapshot_delete_selected,
    NYANNECO_OT_object_snapshot_unarchive_selected,
    NYANNECO_OT_object_snapshot_delete_selected_archived,
    NYANNECO_OT_object_snapshot_commit,
    NYANNECO_OT_object_snapshot_restore,
    NYANNECO_OT_object_snapshot_discard_draft,
    NYANNECO_OT_object_snapshot_history,
    NYANNECO_OT_object_snapshot_delete,
    NYANNECO_OT_object_snapshot_archive,
    NYANNECO_OT_object_snapshot_unarchive,
    NYANNECO_OT_object_snapshot_remessage,
    NYANNECO_OT_object_snapshot_fork,
    NYANNECO_OT_object_snapshot_merge_fork,
    NYANNECO_OT_object_snapshot_regenerate_object_thumbnails,
    NYANNECO_OT_object_snapshot_delete_object_history,
    NYANNECO_OT_object_snapshot_delete_all,
    NYANNECO_OT_object_snapshot_delete_repository,
    NYANNECO_OT_object_snapshot_repair_repository,
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

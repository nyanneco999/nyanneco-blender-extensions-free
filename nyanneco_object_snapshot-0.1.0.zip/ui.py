from __future__ import annotations

from datetime import datetime

import bpy

from .constants import OBJECT_UUID_PROP, SUPPORTED_OBJECT_TYPES
from .features import (
    FEATURE_ARCHIVE,
    FEATURE_BATCH_OPERATIONS,
    FEATURE_BRANCH,
    FEATURE_MERGE,
    FEATURE_TIMER_AUTOCOMMIT,
    commit_limit_issue,
    feature_disabled_issue,
    is_feature_enabled,
)
from .preview import get_current_snapshot_icon_id, get_draft_snapshot_icon_id, get_thumbnail_icon_id
from .selection import selected_archived_commit_ids, selected_commit_ids
from .storage import (
    has_duplicate_object_uuid,
    load_history_readonly,
    repository_integrity_status,
)
from .translations import iface_format, iface_text

VISIBLE_COMMIT_LIMIT = 5


def issue_text(issue) -> str:
    return iface_format(issue.message, **issue.kwargs)


def draw_collapsible_card_header(
    layout: bpy.types.UILayout,
    context: bpy.types.Context,
    prop_name: str,
    label: str,
    right_icon: str = "",
) -> bool:
    is_expanded = bool(getattr(context.scene, prop_name))
    icon = "TRIA_DOWN" if is_expanded else "TRIA_RIGHT"
    header = layout.row(align=True)
    toggle = header.operator(
        "nyanneco_object_snapshot.toggle_scene_bool",
        text="",
        icon=icon,
        emboss=False,
    )
    toggle.prop_name = prop_name
    label_row = header.row(align=True)
    label_row.alignment = "CENTER"
    label_row.label(text=iface_text(label))
    if right_icon:
        header.label(text="", icon=right_icon)
    return is_expanded


def format_commit_time(value: str) -> str:
    try:
        timestamp = datetime.fromisoformat(value)
    except ValueError:
        return value

    if timestamp.tzinfo is not None:
        timestamp = timestamp.astimezone()
    return timestamp.strftime("%Y/%m/%d %H:%M")


def short_commit_id(commit_id: str) -> str:
    return commit_id[:6]


def get_object_history(context: bpy.types.Context):
    obj = context.object
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        return None

    object_uuid = obj.get(OBJECT_UUID_PROP)
    if not object_uuid:
        return None

    return load_history_readonly().objects.get(str(object_uuid))


def schedule_duplicate_uuid_repair() -> None:
    from . import handlers

    handlers.schedule_duplicate_uuid_repair()


def draw_pending_state_card(layout: bpy.types.UILayout) -> None:
    layout.separator()
    box = layout.box()
    box.label(text=iface_text("Checking copied object state..."), icon="FILE_REFRESH")


def draw_repository_damage_card(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    status = repository_integrity_status()
    box = layout.box()
    title = box.row()
    title.alert = True
    title.label(text=iface_text("Snapshot repository may be damaged."), icon="ERROR")

    if status.collection_missing:
        box.label(
            text=iface_text("Snapshot repository collection is missing."),
            icon="OUTLINER_COLLECTION",
        )
    if status.unlinked_snapshot_object_names:
        box.label(
            text=iface_text("Snapshot repository has {count} exposed snapshot objects.").format(
                count=len(status.unlinked_snapshot_object_names),
            ),
            icon="HIDE_OFF",
        )
    if status.missing_snapshot_object_names:
        box.label(
            text=iface_text("Snapshot repository is missing {count} snapshot objects.").format(
                count=len(status.missing_snapshot_object_names),
            ),
            icon="CANCEL",
        )

    box.label(
        text=iface_text("Snapshot actions are disabled until the repository is repaired."),
        icon="LOCKED",
    )

    repair_row = box.row()
    repair_row.operator_context = "EXEC_DEFAULT"
    repair_row.enabled = status.can_repair
    repair_row.operator(
        "nyanneco_object_snapshot.repair_repository",
        text=iface_text("Repair Snapshot Repository"),
        icon="FILE_REFRESH",
    )

    if not status.is_unrecoverable:
        return

    delete_row = box.row()
    delete_row.alert = True
    delete_row.operator_context = "INVOKE_DEFAULT"
    delete_row.operator(
        "nyanneco_object_snapshot.delete_repository",
        text=iface_text("Delete Repository"),
        icon="CANCEL",
    )


def draw_repository_missing_warning_card(layout: bpy.types.UILayout) -> None:
    status = repository_integrity_status()
    if not status.missing_snapshot_object_names:
        return

    box = layout.box()
    title = box.row()
    title.alert = True
    title.label(text=iface_text("Some snapshot contents are missing."), icon="ERROR")
    box.label(
        text=iface_text("Snapshot repository is missing {count} snapshot objects.").format(
            count=len(status.missing_snapshot_object_names),
        ),
        icon="CANCEL",
    )


def draw_delete_card(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    layout.separator()
    box = layout.box()
    if not draw_collapsible_card_header(
        box,
        context,
        "nyanneco_object_snapshot_show_delete_operations",
        "Delete Operations",
    ):
        return

    object_row = box.row()
    object_row.operator_context = "INVOKE_DEFAULT"
    object_history = get_object_history(context)
    object_row.enabled = object_history is not None and bool(object_history.commits)
    object_row.operator(
        "nyanneco_object_snapshot.delete_object_history",
        text=iface_text("Delete Selected Object History"),
        icon="TRASH",
    )
    history_row = box.row()
    history_row.operator_context = "INVOKE_DEFAULT"
    history_row.operator(
        "nyanneco_object_snapshot.delete_all",
        text=iface_text("Delete All History"),
        icon="TRASH",
    )
    delete_row = box.row()
    delete_row.alert = True
    delete_row.operator_context = "INVOKE_DEFAULT"
    delete_row.operator(
        "nyanneco_object_snapshot.delete_repository",
        text=iface_text("Delete Repository"),
        icon="CANCEL",
    )


def draw_settings_card(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    layout.separator()
    box = layout.box()
    if not draw_collapsible_card_header(
        box,
        context,
        "nyanneco_object_snapshot_show_settings_card",
        "Settings",
        right_icon="TOOL_SETTINGS",
    ):
        return

    timer_feature_enabled = is_feature_enabled(FEATURE_TIMER_AUTOCOMMIT)
    timer_toggle_row = box.row()
    timer_toggle_row.enabled = timer_feature_enabled
    timer_toggle_row.prop(context.scene, "nyanneco_object_snapshot_timer_autocommit_enabled")
    timer_row = box.row(align=True)
    timer_row.enabled = (
        timer_feature_enabled and context.scene.nyanneco_object_snapshot_timer_autocommit_enabled
    )
    timer_row.prop(
        context.scene,
        "nyanneco_object_snapshot_timer_autocommit_minutes",
        text=iface_text("Timer Settings"),
    )
    notify_row = box.row()
    notify_row.enabled = timer_feature_enabled
    notify_row.prop(context.scene, "nyanneco_object_snapshot_notify_autocommit")
    archive_confirm_row = box.row()
    archive_confirm_row.enabled = is_feature_enabled(FEATURE_ARCHIVE)
    archive_confirm_row.prop(context.scene, "nyanneco_object_snapshot_confirm_archive")
    timer_issue = feature_disabled_issue(FEATURE_TIMER_AUTOCOMMIT)
    if timer_issue is not None:
        box.label(text=issue_text(timer_issue), icon="LOCKED")
    box.separator()
    box.prop(
        context.scene,
        "nyanneco_object_snapshot_show_thumbnail_settings",
        text=iface_text("Thumbnail Settings"),
    )
    if not context.scene.nyanneco_object_snapshot_show_thumbnail_settings:
        return

    object_history = get_object_history(context)
    regenerate_row = box.row()
    regenerate_row.operator_context = "EXEC_DEFAULT"
    regenerate_row.enabled = object_history is not None and bool(object_history.commits)
    regenerate_row.operator(
        "nyanneco_object_snapshot.regenerate_object_thumbnails",
        text=iface_text("Regenerate Selected Object Thumbnails"),
        icon="FILE_REFRESH",
    )
    box.prop(context.scene, "nyanneco_object_snapshot_hide_thumbnails")


def draw_history_list_card(
    layout: bpy.types.UILayout,
    context: bpy.types.Context,
    object_history,
) -> None:
    layout.separator()
    box = layout.box()
    if not draw_collapsible_card_header(
        box,
        context,
        "nyanneco_object_snapshot_show_history_list",
        "History List",
    ):
        return

    draw_commit_list(box, context, object_history)


def draw_branch_card(
    layout: bpy.types.UILayout,
    object_history,
) -> None:
    if not object_history.branch_source_object_uuid:
        return

    layout.separator()
    box = layout.box()
    box.label(text=iface_text("Branch"), icon="DUPLICATE")
    merge_row = box.row()
    merge_row.operator_context = "INVOKE_DEFAULT"
    merge_row.enabled = is_feature_enabled(FEATURE_MERGE)
    merge_row.operator(
        "nyanneco_object_snapshot.merge_fork",
        text=iface_text("Merge Branch to Source"),
        icon="FILE_TICK",
    )
    merge_issue = feature_disabled_issue(FEATURE_MERGE)
    if merge_issue is not None:
        box.label(text=issue_text(merge_issue), icon="LOCKED")


def draw_history_controls(layout: bpy.types.UILayout, context: bpy.types.Context) -> None:
    status = repository_integrity_status()
    if status.blocks_ui:
        draw_repository_damage_card(layout, context)
        return
    draw_repository_missing_warning_card(layout)

    obj = context.object
    if obj is None or obj.type not in SUPPORTED_OBJECT_TYPES:
        layout.label(text=iface_text("Select a mesh or curve object."), icon="ERROR")
        draw_delete_card(layout, context)
        draw_settings_card(layout, context)
        return

    is_object_mode = obj.mode == "OBJECT"
    if not is_object_mode:
        layout.label(
            text=iface_text("Object Snapshot actions are available in Object Mode only."),
            icon="INFO",
        )

    if has_duplicate_object_uuid(obj):
        schedule_duplicate_uuid_repair()
        draw_pending_state_card(layout)
        draw_settings_card(layout, context)
        return

    history = load_history_readonly()
    object_uuid = obj.get(OBJECT_UUID_PROP)
    limit_issue = commit_limit_issue(history, str(object_uuid) if object_uuid else None)

    commit_row = layout.row(align=True)
    commit_row.scale_y = 1.2
    commit_row.operator_context = "INVOKE_DEFAULT"
    commit_row.enabled = is_object_mode and limit_issue is None
    commit_row.operator("nyanneco_object_snapshot.commit", icon="FILE_TICK")
    if limit_issue is not None:
        layout.label(text=issue_text(limit_issue), icon="LOCKED")

    object_history = get_object_history(context)
    if object_history is None or not object_history.commits:
        layout.label(text=iface_text("No snapshots for this object."), icon="INFO")
        draw_delete_card(layout, context)
        draw_settings_card(layout, context)
        return

    draw_branch_card(layout, object_history)
    draw_history_list_card(layout, context, object_history)
    draw_delete_card(layout, context)
    draw_settings_card(layout, context)


def draw_commit_list(
    layout: bpy.types.UILayout,
    context: bpy.types.Context,
    object_history,
) -> None:
    selected_ids = selected_commit_ids(context.scene)
    selected_archived_ids = selected_archived_commit_ids(context.scene)

    archived_commit_ids = set(object_history.archived_commit_ids)
    commits = list(reversed(object_history.commits))
    main_commits = [commit for commit in commits if commit.commit_id not in archived_commit_ids]
    archived_commits = [commit for commit in commits if commit.commit_id in archived_commit_ids]
    main_commit_ids = {commit.commit_id for commit in main_commits}
    archived_visible_commit_ids = {commit.commit_id for commit in archived_commits}

    draw_batch_operation_row(layout, len(selected_ids & main_commit_ids))

    visible_commits = main_commits[:VISIBLE_COMMIT_LIMIT]
    older_commits = main_commits[VISIBLE_COMMIT_LIMIT:]

    for commit in visible_commits:
        draw_commit_row(
            layout,
            context,
            object_history,
            commit,
            selected=commit.commit_id in selected_ids,
        )

    if older_commits:
        row = layout.row(align=True)
        show_older = context.scene.nyanneco_object_snapshot_show_older_commits
        icon = "TRIA_DOWN" if show_older else "TRIA_RIGHT"
        row.prop(
            context.scene,
            "nyanneco_object_snapshot_show_older_commits",
            text=f"{iface_text('Older Snapshots')} ({len(older_commits)})",
            icon=icon,
            toggle=True,
        )

        if show_older:
            for commit in older_commits:
                draw_commit_row(
                    layout,
                    context,
                    object_history,
                    commit,
                    selected=commit.commit_id in selected_ids,
                )

    if not archived_commits:
        return

    row = layout.row(align=True)
    show_archived = context.scene.nyanneco_object_snapshot_show_archived_commits
    icon = "TRIA_DOWN" if show_archived else "TRIA_RIGHT"
    row.prop(
        context.scene,
        "nyanneco_object_snapshot_show_archived_commits",
        text=f"{iface_text('Archived Snapshots')} ({len(archived_commits)})",
        icon=icon,
        toggle=True,
    )

    if not show_archived:
        return

    draw_archived_batch_operation_row(
        layout,
        len(selected_archived_ids & archived_visible_commit_ids),
    )

    for commit in archived_commits:
        draw_commit_row(
            layout,
            context,
            object_history,
            commit,
            archived=True,
            selected=commit.commit_id in selected_archived_ids,
        )


def draw_batch_operation_row(layout: bpy.types.UILayout, selected_count: int) -> None:
    row = layout.row(align=True)
    batch_enabled = is_feature_enabled(FEATURE_BATCH_OPERATIONS)
    archive_enabled = is_feature_enabled(FEATURE_ARCHIVE)
    row.enabled = batch_enabled
    row.operator(
        "nyanneco_object_snapshot.select_visible",
        text="",
        icon="CHECKBOX_HLT",
    )
    clear_row = row.row(align=True)
    clear_row.enabled = batch_enabled and selected_count > 0
    clear_row.operator(
        "nyanneco_object_snapshot.clear_selection",
        text="",
        icon="CHECKBOX_DEHLT",
    )
    archive_row = row.row(align=True)
    archive_row.enabled = batch_enabled and archive_enabled and selected_count > 0
    archive_row.operator_context = "INVOKE_DEFAULT"
    archive_row.operator(
        "nyanneco_object_snapshot.archive_selected",
        text="",
        icon="FILE_FOLDER",
    )
    delete_row = row.row(align=True)
    delete_row.enabled = batch_enabled and selected_count > 0
    delete_row.operator_context = "INVOKE_DEFAULT"
    delete_row.operator(
        "nyanneco_object_snapshot.delete_selected",
        text="",
        icon="TRASH",
    )
    row.label(text=f"{iface_text('Checked')}: {selected_count}")
    batch_issue = feature_disabled_issue(FEATURE_BATCH_OPERATIONS)
    if batch_issue is not None:
        layout.label(text=issue_text(batch_issue), icon="LOCKED")


def draw_archived_batch_operation_row(layout: bpy.types.UILayout, selected_count: int) -> None:
    row = layout.row(align=True)
    batch_enabled = is_feature_enabled(FEATURE_BATCH_OPERATIONS)
    archive_enabled = is_feature_enabled(FEATURE_ARCHIVE)
    row.enabled = batch_enabled
    row.operator(
        "nyanneco_object_snapshot.select_visible_archived",
        text="",
        icon="CHECKBOX_HLT",
    )
    clear_row = row.row(align=True)
    clear_row.enabled = batch_enabled and selected_count > 0
    clear_row.operator(
        "nyanneco_object_snapshot.clear_archived_selection",
        text="",
        icon="CHECKBOX_DEHLT",
    )
    unarchive_row = row.row(align=True)
    unarchive_row.enabled = batch_enabled and archive_enabled and selected_count > 0
    unarchive_row.operator(
        "nyanneco_object_snapshot.unarchive_selected",
        text="",
        icon="TRIA_UP",
    )
    delete_row = row.row(align=True)
    delete_row.enabled = batch_enabled and selected_count > 0
    delete_row.operator_context = "INVOKE_DEFAULT"
    delete_row.operator(
        "nyanneco_object_snapshot.delete_selected_archived",
        text="",
        icon="TRASH",
    )
    row.label(text=f"{iface_text('Archived Checked')}: {selected_count}")
    batch_issue = feature_disabled_issue(FEATURE_BATCH_OPERATIONS)
    if batch_issue is not None:
        layout.label(text=issue_text(batch_issue), icon="LOCKED")


def draw_commit_action_buttons(
    layout: bpy.types.UILayout,
    commit,
    archived: bool,
    has_draft: bool,
    selected: bool,
) -> None:
    row = layout.row(align=True)
    row.operator_context = "INVOKE_DEFAULT"
    restore = row.operator(
        "nyanneco_object_snapshot.restore",
        text="",
        icon="FILE_REFRESH",
    )
    restore.commit_id = commit.commit_id
    fork_row = row.row(align=True)
    fork_row.enabled = is_feature_enabled(FEATURE_BRANCH)
    fork = fork_row.operator(
        "nyanneco_object_snapshot.fork",
        text="",
        icon="DUPLICATE",
    )
    fork.commit_id = commit.commit_id
    remessage = row.operator(
        "nyanneco_object_snapshot.remessage",
        text="",
        icon="GREASEPENCIL",
    )
    remessage.commit_id = commit.commit_id
    delete = row.operator(
        "nyanneco_object_snapshot.delete",
        text="",
        icon="TRASH",
    )
    delete.commit_id = commit.commit_id
    if archived:
        archive_row = row.row(align=True)
        archive_row.enabled = is_feature_enabled(FEATURE_ARCHIVE)
        unarchive = archive_row.operator(
            "nyanneco_object_snapshot.unarchive",
            text="",
            icon="TRIA_UP",
        )
        unarchive.commit_id = commit.commit_id
    else:
        archive_row = row.row(align=True)
        archive_row.enabled = is_feature_enabled(FEATURE_ARCHIVE)
        archive = archive_row.operator(
            "nyanneco_object_snapshot.archive",
            text="",
            icon="FILE_FOLDER",
        )
        archive.commit_id = commit.commit_id
    if has_draft:
        discard_draft = row.operator(
            "nyanneco_object_snapshot.discard_draft",
            text="",
            icon="CANCEL",
        )
        discard_draft.commit_id = commit.commit_id
    spacer = row.row(align=True)
    spacer.alignment = "RIGHT"
    spacer.enabled = is_feature_enabled(FEATURE_BATCH_OPERATIONS)
    toggle = spacer.operator(
        "nyanneco_object_snapshot.toggle_select",
        text="",
        icon="CHECKBOX_HLT" if selected else "CHECKBOX_DEHLT",
    )
    toggle.commit_id = commit.commit_id
    toggle.archived = archived


def draw_commit_row(
    layout: bpy.types.UILayout,
    context: bpy.types.Context,
    object_history,
    commit,
    archived: bool = False,
    selected: bool = False,
) -> None:
    is_active = commit.commit_id == object_history.active_commit_id
    draft_commit = object_history.draft_commits.get(commit.commit_id)
    box = layout.box()
    if is_active:
        box = box.box()

    draw_commit_action_buttons(
        box,
        commit,
        archived=archived,
        has_draft=draft_commit is not None,
        selected=selected,
    )
    row = box.row(align=True)
    thumbnail_column = row.column(align=True)
    if not context.scene.nyanneco_object_snapshot_hide_thumbnails:
        thumbnail_commit = draft_commit or commit
        icon_id = get_thumbnail_icon_id(thumbnail_commit.thumbnail_path)
        if icon_id:
            thumbnail_column.template_icon(icon_value=icon_id, scale=3.0)
        else:
            thumbnail_column.label(text="", icon="IMAGE_DATA")

    info = row.column(align=True)
    if is_active:
        status = info.row(align=True)
        status.label(text="", icon_value=get_current_snapshot_icon_id())
        status.label(text=iface_text("Current"), icon="CHECKMARK")
    if draft_commit is not None:
        draft_status = info.row(align=True)
        draft_status.label(text="", icon_value=get_draft_snapshot_icon_id())
        draft_status.label(text=iface_text("Draft"), icon="GREASEPENCIL")
    if archived:
        info.label(text=iface_text("Archived"), icon="FILE_FOLDER")

    info.label(text=format_commit_time(commit.created_at), icon="TIME")
    info.label(text=f"{iface_text('ID')}: {short_commit_id(commit.commit_id)}")
    message = commit.message if commit.message else iface_text("(no message)")
    info.label(text=message)


def draw_object_snapshot_menu(self, context: bpy.types.Context) -> None:
    layout = self.layout
    obj = context.object
    enabled = obj is not None and obj.type in SUPPORTED_OBJECT_TYPES
    layout.separator()
    column = layout.column()
    column.enabled = enabled
    column.operator_context = "INVOKE_DEFAULT"
    column.operator("nyanneco_object_snapshot.commit", icon="FILE_TICK")
    column.operator("nyanneco_object_snapshot.history", icon="TIME")


class NYANNECO_PT_object_snapshot(bpy.types.Panel):
    bl_label = "Nyanneco Object Snapshot"
    bl_idname = "NYANNECO_PT_object_snapshot"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Nyan"

    def draw(self, context: bpy.types.Context) -> None:
        draw_history_controls(self.layout, context)


def append_menu(menu_name: str) -> None:
    menu = getattr(bpy.types, menu_name, None)
    if menu is not None:
        menu.append(draw_object_snapshot_menu)


def remove_menu(menu_name: str) -> None:
    menu = getattr(bpy.types, menu_name, None)
    if menu is not None:
        menu.remove(draw_object_snapshot_menu)


def register():
    bpy.utils.register_class(NYANNECO_PT_object_snapshot)
    append_menu("VIEW3D_MT_object_context_menu")
    append_menu("OUTLINER_MT_context_menu")
    append_menu("OUTLINER_MT_object")


def unregister():
    remove_menu("OUTLINER_MT_object")
    remove_menu("OUTLINER_MT_context_menu")
    remove_menu("VIEW3D_MT_object_context_menu")
    bpy.utils.unregister_class(NYANNECO_PT_object_snapshot)

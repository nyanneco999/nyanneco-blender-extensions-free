bl_info = {
    "name": "Nyanneco Object Snapshot",
    "author": "nyanneco",
    "version": (0, 1, 0),
    "blender": (4, 2, 0),
    "location": "Object context menu",
    "description": "Object-level snapshot history for mesh and curve objects.",
    "category": "Object",
}

from . import handlers, operators, preview, properties, translations, ui  # noqa: E402

MODULES = (
    translations,
    properties,
    operators,
    preview,
    ui,
    handlers,
)


def register():
    for module in MODULES:
        module.register()


def unregister():
    for module in reversed(MODULES):
        module.unregister()

from __future__ import annotations

from dataclasses import dataclass

from .models import HistoryDocument

EDITION_PAID = "paid"
EDITION_FREE = "free"

# Change this to EDITION_FREE when packaging the free distribution.
EDITION = EDITION_PAID

FEATURE_ARCHIVE = "archive"
FEATURE_BATCH_OPERATIONS = "batch_operations"
FEATURE_BRANCH = "branch"
FEATURE_MERGE = "merge"
FEATURE_TIMER_AUTOCOMMIT = "timer_autocommit"

FREE_OBJECT_COMMIT_LIMIT = 10
FREE_SCENE_COMMIT_LIMIT = 50

FREE_DISABLED_FEATURES = frozenset(
    {
        FEATURE_ARCHIVE,
        FEATURE_BATCH_OPERATIONS,
        FEATURE_BRANCH,
        FEATURE_MERGE,
        FEATURE_TIMER_AUTOCOMMIT,
    }
)


@dataclass(frozen=True, slots=True)
class FeatureIssue:
    message: str
    kwargs: dict[str, object]


def is_free_edition() -> bool:
    return EDITION == EDITION_FREE


def is_feature_enabled(feature: str) -> bool:
    return not is_free_edition() or feature not in FREE_DISABLED_FEATURES


def feature_disabled_issue(feature: str) -> FeatureIssue | None:
    if is_feature_enabled(feature):
        return None
    return FeatureIssue("This feature is available in the paid version.", {})


def object_commit_count(history: HistoryDocument, object_uuid: str | None) -> int:
    if not object_uuid:
        return 0
    object_history = history.objects.get(str(object_uuid))
    if object_history is None:
        return 0
    return len(object_history.commits)


def scene_commit_count(history: HistoryDocument) -> int:
    return sum(len(object_history.commits) for object_history in history.objects.values())


def commit_limit_issue(
    history: HistoryDocument,
    object_uuid: str | None,
) -> FeatureIssue | None:
    if not is_free_edition():
        return None

    if object_commit_count(history, object_uuid) >= FREE_OBJECT_COMMIT_LIMIT:
        return FeatureIssue(
            "Free version limit reached: {count} commits per object.",
            {"count": FREE_OBJECT_COMMIT_LIMIT},
        )

    if scene_commit_count(history) >= FREE_SCENE_COMMIT_LIMIT:
        return FeatureIssue(
            "Free version limit reached: {count} commits per scene.",
            {"count": FREE_SCENE_COMMIT_LIMIT},
        )

    return None

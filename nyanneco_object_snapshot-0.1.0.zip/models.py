from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

SCHEMA_VERSION = 1


@dataclass(slots=True)
class CommitRecord:
    commit_id: str
    object_uuid: str
    source_object_name: str
    snapshot_object_name: str
    snapshot_data_name: str | None
    object_type: str
    created_at: str
    message: str = ""
    thumbnail_path: str | None = None
    material_names: list[str | None] | None = None
    object_state: dict[str, Any] | None = None
    branch_source_object_uuid: str | None = None
    branch_source_commit_id: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CommitRecord:
        if not isinstance(data, dict):
            raise ValueError("Commit history entry must be an object.")
        return cls(
            commit_id=str(data["commit_id"]),
            object_uuid=str(data["object_uuid"]),
            source_object_name=str(data["source_object_name"]),
            snapshot_object_name=str(data["snapshot_object_name"]),
            snapshot_data_name=data.get("snapshot_data_name"),
            object_type=str(data["object_type"]),
            created_at=str(data["created_at"]),
            message=str(data.get("message", "")),
            thumbnail_path=data.get("thumbnail_path"),
            material_names=data.get("material_names"),
            object_state=data.get("object_state"),
            branch_source_object_uuid=data.get(
                "branch_source_object_uuid",
                data.get("forked_from_object_uuid"),
            ),
            branch_source_commit_id=data.get(
                "branch_source_commit_id",
                data.get("forked_from_commit_id"),
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(slots=True)
class ObjectHistory:
    object_uuid: str
    display_name: str
    active_commit_id: str | None = None
    branch_source_object_uuid: str | None = None
    branch_source_commit_id: str | None = None
    draft_commits: dict[str, CommitRecord] = field(default_factory=dict)
    archived_commit_ids: list[str] = field(default_factory=list)
    commits: list[CommitRecord] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ObjectHistory:
        if not isinstance(data, dict):
            raise ValueError("Object history entry must be an object.")

        commits_data = data.get("commits", [])
        draft_commits_data = data.get("draft_commits", {})
        archived_commit_ids_data = data.get("archived_commit_ids", [])
        if not isinstance(commits_data, list):
            raise ValueError("Object history commits must be a list.")
        if not isinstance(draft_commits_data, dict):
            raise ValueError("Object history drafts must be an object.")
        if not isinstance(archived_commit_ids_data, list):
            raise ValueError("Archived commit IDs must be a list.")

        commits = [CommitRecord.from_dict(item) for item in commits_data]
        commits.sort(key=lambda item: item.created_at)
        active_commit_id = data.get("active_commit_id")
        commit_ids = {commit.commit_id for commit in commits}
        if active_commit_id not in commit_ids:
            active_commit_id = commits[-1].commit_id if commits else None
        draft_commits = {
            str(commit_id): CommitRecord.from_dict(commit_data)
            for commit_id, commit_data in draft_commits_data.items()
        }
        archived_commit_ids = [
            str(commit_id) for commit_id in archived_commit_ids_data if isinstance(commit_id, str)
        ]
        return cls(
            object_uuid=str(data["object_uuid"]),
            display_name=str(data.get("display_name", "")),
            active_commit_id=active_commit_id,
            branch_source_object_uuid=data.get(
                "branch_source_object_uuid",
                data.get("forked_from_object_uuid"),
            ),
            branch_source_commit_id=data.get(
                "branch_source_commit_id",
                data.get("forked_from_commit_id"),
            ),
            draft_commits=draft_commits,
            archived_commit_ids=archived_commit_ids,
            commits=commits,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "object_uuid": self.object_uuid,
            "display_name": self.display_name,
            "active_commit_id": self.active_commit_id,
            "branch_source_object_uuid": self.branch_source_object_uuid,
            "branch_source_commit_id": self.branch_source_commit_id,
            "draft_commits": {
                commit_id: commit.to_dict()
                for commit_id, commit in sorted(self.draft_commits.items())
            },
            "archived_commit_ids": sorted(set(self.archived_commit_ids)),
            "commits": [commit.to_dict() for commit in self.commits],
        }

    def add_commit(self, commit: CommitRecord) -> None:
        self.display_name = commit.source_object_name
        self.active_commit_id = commit.commit_id
        self.commits.append(commit)
        self.commits.sort(key=lambda item: item.created_at)

    def get_commit(self, commit_id: str) -> CommitRecord | None:
        for commit in self.commits:
            if commit.commit_id == commit_id:
                return commit
        return None

    def remove_commit(self, commit_id: str) -> CommitRecord | None:
        for index, commit in enumerate(self.commits):
            if commit.commit_id != commit_id:
                continue

            removed = self.commits.pop(index)
            if removed.commit_id in self.archived_commit_ids:
                self.archived_commit_ids.remove(removed.commit_id)
            if self.active_commit_id == removed.commit_id:
                self.active_commit_id = self.commits[-1].commit_id if self.commits else None
            return removed
        return None

    def clear_commits(self) -> list[CommitRecord]:
        removed = list(self.commits)
        removed.extend(self.draft_commits.values())
        self.commits.clear()
        self.draft_commits.clear()
        self.archived_commit_ids.clear()
        self.active_commit_id = None
        return removed


@dataclass(slots=True)
class HistoryDocument:
    version: int = SCHEMA_VERSION
    objects: dict[str, ObjectHistory] = field(default_factory=dict)

    @classmethod
    def empty(cls) -> HistoryDocument:
        return cls()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> HistoryDocument:
        if not isinstance(data, dict):
            raise ValueError("Snapshot history document must be an object.")

        objects_data = data.get("objects", {})
        if not isinstance(objects_data, dict):
            raise ValueError("Snapshot history objects must be an object.")

        objects = {
            object_uuid: ObjectHistory.from_dict(history_data)
            for object_uuid, history_data in objects_data.items()
        }
        return cls(version=int(data.get("version", SCHEMA_VERSION)), objects=objects)

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "objects": {
                object_uuid: history.to_dict()
                for object_uuid, history in sorted(self.objects.items())
            },
        }

    def ensure_object(self, object_uuid: str, display_name: str) -> ObjectHistory:
        history = self.objects.get(object_uuid)
        if history is None:
            history = ObjectHistory(object_uuid=object_uuid, display_name=display_name)
            self.objects[object_uuid] = history
        else:
            history.display_name = display_name
        return history

    def add_commit(self, commit: CommitRecord) -> None:
        self.ensure_object(commit.object_uuid, commit.source_object_name).add_commit(commit)

    def get_commit(self, object_uuid: str, commit_id: str) -> CommitRecord | None:
        history = self.objects.get(object_uuid)
        if history is None:
            return None
        return history.get_commit(commit_id)

    def remove_commit(self, object_uuid: str, commit_id: str) -> CommitRecord | None:
        history = self.objects.get(object_uuid)
        if history is None:
            return None

        removed = history.remove_commit(commit_id)
        if removed is not None and not history.commits:
            del self.objects[object_uuid]
        return removed

    def clear_object_commits(self, object_uuid: str) -> list[CommitRecord]:
        history = self.objects.pop(object_uuid, None)
        if history is None:
            return []
        return history.clear_commits()
